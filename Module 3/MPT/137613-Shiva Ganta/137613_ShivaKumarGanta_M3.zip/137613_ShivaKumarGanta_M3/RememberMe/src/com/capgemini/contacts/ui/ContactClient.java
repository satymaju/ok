package com.capgemini.contacts.ui;

import java.util.Scanner;

import com.capgemini.contacts.bean.ContactDetails;
import com.capgemini.contacts.service.ContactsHelper;
import com.capgemini.contacts.service.ContactsValidator;

public class ContactClient {

	Scanner sc=new Scanner(System.in);
	ContactsValidator contactvalidator=new ContactsValidator();
	ContactsHelper contactHelper=new ContactsHelper();
	
	/*------------------------------------------------------------------------------------------------------------*/		
	
	private void addContact()
	{
		ContactDetails contact=new ContactDetails();
		System.out.println("Enter name: ");
		contact.setcName(sc.nextLine());
		
		System.out.println("Enter Mobile No.: ");
		contact.setMobileNo1(sc.nextLine());
		
		System.out.println("Do you want to add alternate Mobile No. ? (Y/N) ");
		char choice=sc.nextLine().charAt(0);
		if(choice=='Y'||choice=='y')
		{
			System.out.println("Enter Mobile No.: ");
			contact.setMobileNo2(sc.nextLine());
		}
		else
			contact.setMobileNo2(null);  //setting alternate number to null when user gives 'N' or 'n' as choice
		
		System.out.println("Enter Email ID: ");
		contact.setEmailID(sc.nextLine());
		
		System.out.println("Select the Group (Friends/Family/CoWorkers) : ");
		contact.setGroupName(sc.nextLine());
		
		if(contactvalidator.validateDetails(contact))
		{
			contactHelper.addContactDetails(contact);
				
		}
		
	}
	
	/*------------------------------------------------------------------------------------------------------------*/		
	
	private void delContact()
	{
		System.out.println("\n\tDelete a Contact\n");
		System.out.println("Enter contact ID: ");
		try
		{
			int id=Integer.parseInt(sc.nextLine()); //throws exception when we enter data other than numbers
			contactHelper.deleteContactDetails(id);
		}
		catch(NumberFormatException e)  //implicit exception handled here
		{
			 System.out.println("Contact ID must be a number. Error at:"+e.getMessage()+"\nFailed to delete the contact.\n");
			 
		}
		
	}
	
	/*------------------------------------------------------------------------------------------------------------*/		
	
	public void menu()
	{
		int choice;
		boolean flag=true;
		do
		{
			System.out.println("\t\tREMEMBER ME\n");
			System.out.println("Available Services: \n\t1.Add New Contact\n\t2.Delete Contact\n\t3.Exit\n");
			
			System.out.println("Enter option number: ");
			try
			{
				choice=Integer.parseInt(sc.nextLine()); //exception raises here when we give data other than numbers
			switch(choice)
			{
			case 1: addContact();
					break;
			case 2:delContact();
					break;
			case 3: System.exit(0);
					flag=false;
					break;
			default: System.out.println("Enter a correct choice!  Please Try Again.\n ");
			}
			}
			catch(NumberFormatException e)  //implicit exception handled here
			{
				 System.out.println("Choice must be a number. Error at:"+e.getMessage()+"\nEnter a valid choice\n");
				 
			}
		}while(flag);
		
	}
	
	/*------------------------------------------------------------------------------------------------------------*/	
	
	public static void main(String args[])
	{
		ContactClient obj=new ContactClient();
		obj.menu();
	}
}
