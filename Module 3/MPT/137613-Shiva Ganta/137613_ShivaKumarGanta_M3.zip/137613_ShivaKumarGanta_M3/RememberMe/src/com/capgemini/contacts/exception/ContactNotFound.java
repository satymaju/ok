package com.capgemini.contacts.exception;

public class ContactNotFound extends Exception{
	
	@Override
	public String getMessage()
	{
		return "Contact ID does not exists. Failed to delete the contact.\n";
	}
}
