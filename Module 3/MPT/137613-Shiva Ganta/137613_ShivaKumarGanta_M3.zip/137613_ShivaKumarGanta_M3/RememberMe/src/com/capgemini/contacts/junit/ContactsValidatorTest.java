package com.capgemini.contacts.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.contacts.bean.ContactDetails;
import com.capgemini.contacts.service.ContactsValidator;

public class ContactsValidatorTest 
{

	ContactsValidator obj=new ContactsValidator();
	@Test
	public void testvalidateCName()
	{
		assertEquals(true,obj.validateCName("Jatheesha"));
	}
	
	@Test
	public void testvalidateMobileNo()
	{
		assertEquals(true,obj.validateMobileNo("7396444123"));
	}
	
	@Test
	public void testvalidateEmailID()
	{
		assertEquals(true,obj.validateEmailID("Jathi@yahoo.org"));
	}
	
	@Test
	public void testvalidateGroupName()
	{
		assertEquals(true,obj.validateGroupName("Family"));
	}
	
	ContactDetails contact=new ContactDetails(4,"Shiva Kumar","9573829693",null,"shiva@gmail.com","Friends");
	@Test
	public void testvalidateDetails()
	{
		assertEquals(true,obj.validateDetails(contact));
	}

}
