package com.capgemini.contacts.exception;

public class DuplicateContactException extends Exception{

	@Override
	public String getMessage()
	{
		return "Duplicate Contact. Failed to add the Contact.\n";
	}
}
