package com.capgemini.contacts.service;

import com.capgemini.contacts.bean.ContactDetails;

public class ContactsValidator {
	
	public boolean validateCName(String cName)
	{
		if(cName.matches("[a-zA-Z\\s]{5,16}"))
			return true;
		System.out.println("Invalid contact name. Only 5-15 alphabets are allowed with optional space. \n");
		return false;
	}
	
	public boolean validateMobileNo(String mobileNo)
	{
		if(mobileNo.matches("[7-9][0-9]{9}"))
			return true;
		System.out.println("Invalid mobile No. It should start with 7/8/9 and must contain 10 digits.\n");
		return false;
	}
	
	public boolean validateEmailID(String emailID)
	{
		if(emailID.matches("\\b[\\w.%-]+@[-.\\w]+\\.[A-Za-z]{2,4}\\b"))
			return true;
		System.out.println("Invalid email ID. Please check the email ID format.\n");
		return false;
	}
	
	public boolean validateGroupName(String groupName)
	{
		String str=groupName.toLowerCase();
		if(str.matches("friends") || str.matches("family") || str.matches("coworkers"))
			return true;
		System.out.println("Invalid group name. Enter group name from given options only");
		return false;
	}
	
	public boolean validateDetails(ContactDetails obj)
	{
		if(validateCName(obj.getcName()) && validateMobileNo(obj.getMobileNo1()) && validateEmailID(obj.getEmailID()) && validateGroupName(obj.getGroupName()))
		{
			if(obj.getMobileNo2()!=null)
			{
				if(validateMobileNo(obj.getMobileNo2()))
					return true;
			}
			else
			{
				return true;
			}
		}
		System.out.println("Failed to add the Contact\n");
		return false;
	}
}
