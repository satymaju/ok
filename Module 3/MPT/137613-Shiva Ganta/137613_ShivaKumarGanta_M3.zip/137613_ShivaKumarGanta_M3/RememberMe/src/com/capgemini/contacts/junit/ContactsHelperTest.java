package com.capgemini.contacts.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.contacts.bean.ContactDetails;
import com.capgemini.contacts.service.ContactsHelper;

public class ContactsHelperTest {

	ContactsHelper obj=new ContactsHelper();
	ContactDetails contact=new ContactDetails(5,"Raj Singh","9573829693",null,"shiva@gmail.com","Friends");
	
	@Test
	public void testaddContactDetails() {
		assertEquals(true,obj.addContactDetails(contact));
		   //here validations are not tested because validations are implemented separately in ContactClient class
			//checks only for duplicate contact entry
	}

	@Test
	public void testdeleteContactDetails() {
		assertEquals(true,obj.deleteContactDetails(4));
	}
}
