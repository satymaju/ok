package com.capgemini.contacts.bean;

public class ContactDetails {

	int contactID;
	String cName;
	String mobileNo1;
	String mobileNo2;
	String emailID;
	String groupName;
	
	public ContactDetails()
	{
		contactID=(int)(Math.random()*10)+1;  //Autogenerating contactID using random() function
	}
	
	public ContactDetails(int contactID,String cName, String mobileNo1, String mobileNo2,String emailID, String groupName) 
	{			//parameterised constructor
		this.contactID=contactID;
		this.cName = cName;
		this.mobileNo1 = mobileNo1;
		this.mobileNo2 = mobileNo2;
		this.emailID = emailID;
		this.groupName = groupName;
	}
	
	public int getContactID() {
		return contactID;
	}

	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	
	public String getMobileNo1() {
		return mobileNo1;
	}
	public void setMobileNo1(String mobileNo1) {
		this.mobileNo1 = mobileNo1;
	}
	
	public String getMobileNo2() {
		return mobileNo2;
	}
	public void setMobileNo2(String mobileNo2) {
		this.mobileNo2 = mobileNo2;
	}
	
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	public String toString()
	{
		return "ContactName: "+cName+"\nContactId: "+contactID+"\nMobileNo1: "+mobileNo1+"\nGroup Name: "+groupName+"\n";
	}
}
