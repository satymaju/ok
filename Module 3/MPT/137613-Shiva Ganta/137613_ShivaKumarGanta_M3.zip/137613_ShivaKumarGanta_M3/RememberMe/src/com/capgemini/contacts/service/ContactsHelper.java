package com.capgemini.contacts.service;

import com.capgemini.contacts.bean.ContactDetails;
import com.capgemini.contacts.dao.ContactDao;

public class ContactsHelper {
	
	static ContactDao storageList=new ContactDao();
	
	static
	{
		storageList.addToList(new ContactDetails(1,"Kirti Roy","9234534500",null,"kirtiroy@yahoo.co.in","Family"));
		storageList.addToList(new ContactDetails(2,"Raj Singh","8288866678","8234343434","Arun16@gmail.com","Friends"));
	}

	public boolean addContactDetails(ContactDetails conatctDetails)
	{
		return storageList.addToList(conatctDetails);
	}
	
	public boolean deleteContactDetails(int contactID)
	{
		return storageList.delFromList(contactID);
	}
}
