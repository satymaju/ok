package com.capgemini.contacts.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.contacts.bean.ContactDetails;
import com.capgemini.contacts.exception.ContactNotFound;
import com.capgemini.contacts.exception.DuplicateContactException;

public class ContactDao {
	List list=new ArrayList();
	int i;
	
	public boolean addToList(ContactDetails contact)
	{
		String cname=contact.getcName();
		boolean flag=true;
		ContactDetails tempObj;
		for(i=0;i<list.size();i++)
		{
			tempObj=(ContactDetails)list.get(i);
			if(tempObj.getcName().equals(cname))
			{
				flag=false; //when matches, makes flag as false(which means duplicate) and comes out of loop 
				break;
			}
		}
		try
		{
			if(flag)
			{
				list.add(contact);
				System.out.println("Contact Added\n");
				System.out.println(contact);
				return flag;
			}
			else  //throwing user-defined exception when user tries to add a contact with same name as existing one
				throw new DuplicateContactException();
		} 
		catch (DuplicateContactException e) 
		{
			System.out.println(e.getMessage()); //prints the error message
			return flag;
		}
	}
	
	public boolean delFromList(int id)
	{
		boolean flag=false;
		ContactDetails tempObj;
		for(i=0;i<list.size();i++)
		{
			tempObj=(ContactDetails)list.get(i);
			if(tempObj.getContactID()==id)
			{
				list.remove(i);
				System.out.println("Contact Deleted Successfully.\n");
				flag=true;
				break;
			}
		}
		try
		{
			if(flag)
				return flag;
			else
			{     //throwing user-defined exception
				throw new ContactNotFound();
			}
				
		} 
		catch (ContactNotFound e) 
		{
			System.out.println(e.getMessage());
			return flag;
		}
	}
}
