package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeDataValidator;

public class RechargeDataValidatorTestCase {
	
	RechargeDataValidator rdv = new RechargeDataValidator();
	RechargeDetails testdata1= new RechargeDetails("prepaid","airtel","8906980839",511,1234);//..........For All valid Inputs Checking
	RechargeDetails testdata2= new RechargeDetails("prepaid","airtel","8906980839",34879,1234);//.........For Invalid Amount Input Checking
	RechargeDetails testdata3= new RechargeDetails("prepaid","docomo","8906980839",9847,78234);//.........For Invalid TransactionId Checking
	RechargeDetails testdata4= new RechargeDetails("post","docomo","9614276768",3087,4234);//.........For Invalid RechargeType Checking
	RechargeDetails testdata5= new RechargeDetails("postpaid","docomo","1844276768",3087,4234);//........For Invalid Mobile Number checking
	RechargeDetails testdata6= new RechargeDetails("postpaid","vodafone","1844276768",3087,4234);//........For Invalid CurrentOperator checking
	RechargeDetails testdata7= new RechargeDetails("postpaid","jio","9444465810",3087,4234);//........For Invalid CurrentOperator checking
	
	
	@Test
	public void testValidateDetails() {
		assertEquals(true,rdv.validateDetails(testdata1));
	}
	
	@Test
	public void testValidateDetails2() {
		assertEquals(false,rdv.validateDetails(testdata2));
	}
	
	@Test
	public void testValidateDetails3() {
		assertEquals(false,rdv.validateDetails(testdata3));
	}
	
	@Test
	public void testValidateRechargeType() {
		assertEquals(true,rdv.validateRechargeType(testdata1));
	}
	
	@Test
	public void testValidateRechargeType2() {
		assertEquals(false,rdv.validateRechargeType(testdata4));
	}
	
	@Test
	public void testValidateDetails21() {
		assertEquals(false,rdv.validateDetails(testdata5));
	}
	
	@Test
	public void testValidateDetails22() {
		assertEquals(false,rdv.validateDetails(testdata6));
	}
	
	@Test
	public void testValidateDetails10() {
		assertEquals(true,rdv.validateDetails(testdata1));
	}
	
	@Test
	public void testValidateDetails11() {
		assertEquals(true,rdv.validateDetails(testdata7));
	}

}
