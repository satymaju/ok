package com.capgemini.paymobbill.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeFileHelper
{
	public void fileWrite(RechargeDetails obj) {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("MobileBill.obj"));
			oos.writeObject(obj);
			oos.close();
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	public void readFile() {
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream("MobileBill.obj"));
			try {
				System.out.println(ois.readObject());
				ois.close();
			} catch (ClassNotFoundException e) {
				System.out.println(e.getMessage());}
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		
	}

	
}
