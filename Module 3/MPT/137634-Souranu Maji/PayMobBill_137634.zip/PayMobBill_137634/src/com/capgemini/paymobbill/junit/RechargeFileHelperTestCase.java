package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class RechargeFileHelperTestCase {
	
	RechargeFileHelper rfh = new RechargeFileHelper();
	
	RechargeDetails testdata= new RechargeDetails("postpaid","jio","9433234680",510,4256);

	@Test(timeout=50)
	public void testFileWrite() {
		rfh.fileWrite(testdata);
		
	}

	@Test(timeout=200)
	public void testReadFile() {
		rfh.readFile();
	}

}
