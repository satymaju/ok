package com.capgemini.paymobbill.service;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeDataValidator {

	public boolean validateDetails(RechargeDetails rd)//........checking validation of recharge-type, transaction-id,currentoperator and recharge-amount
	{
		if(validateRechargeType(rd) && validateMobileNo(rd) && validateCurrentOperator(rd) && validateAmount(rd) && validateTransactionID(rd))
		{
			return true;
			
		}
		else
		{
			return false;
		}
	}
	private boolean validateTransactionID(RechargeDetails rd)//checking for valid Transaction ID
	{
		String transactionID= Integer.toString(rd.getTransactionID());
		if(transactionID.matches("[0-9]{4}")) //The ID should be of length of 4
		{
			return true;
		}else {
			return false;
		}
		
	}
	private boolean validateAmount(RechargeDetails rd)//...........checking for valid Recharge amount
	{
		double amount=rd.getAmount();
		try {
			if(amount>=10 && amount<=9999)//The amount should be between Rs.10 and Rs.3000
			{
				return true;
			}
			else
			{
				return false;
			}
		}catch(NumberFormatException nfe) {
			System.out.println("Please Enter Valid amount within 9999");
			return false;
		}
	}
	private boolean validateCurrentOperator(RechargeDetails rd)//.......checking the name for valid Current Operator
	{
		String a = rd.getCurrentOperator().toLowerCase();
		String b = rd.getCurrentOperator().toLowerCase();
		String c = rd.getCurrentOperator().toLowerCase();
		String d = rd.getCurrentOperator().toLowerCase();
		if(a.equals("airtel") ||  b.equals("bsnl") || c.equals("docomo")|| d.equals("jio"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	private boolean validateMobileNo(RechargeDetails rd)//.........mobile number format checking
	{
		String MobileNo=rd.getMobileNo();
		if(MobileNo.matches("[7-9][0-9]{9}"))//..........mobile number should start with 7 or 8 or 9 and the number should be of length 10
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean validateRechargeType(RechargeDetails rd)//.............recharge type checking whether it is prepaid or postpaid.
	{
		if(rd.getRechargeType().toLowerCase().equals("prepaid") || rd.getRechargeType().toLowerCase().equals("postpaid"))
		{
			return true;
		}
		else 
		{
			return false;
		}
	}


}
