package com.capgemini.paymobbill.ui;

import java.security.Provider.Service;
import java.util.Scanner;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.exception.InvalidNumberException;
import com.capgemini.paymobbill.service.RechargeDataValidator;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class RechargeClient {
	Scanner scanner = new Scanner(System.in);
	RechargeDetails obj=new RechargeDetails();
	RechargeDataValidator rdv=new RechargeDataValidator();
	RechargeFileHelper rfh = new RechargeFileHelper();
	public static void main(String[] args) {
		RechargeClient rc = new RechargeClient();
		try {
			rc.displayMenu();
		} catch (InvalidNumberException e) {
			
			
		}
	}
	public void displayMenu() throws InvalidNumberException
	{
		System.out.println("1.Make a Recharge");
		System.out.println("2.Display Recharge Details");
		System.out.println("3.Exit");
		int option;
		try{
			option=Integer.parseInt(scanner.nextLine());
		}catch(NumberFormatException nfe){
			throw new InvalidNumberException();
		}
		switch(option)
		{
		case 1:
			addRechargeDetails();//............on entering 1 the user will be able to enter the appropriate-details
			displayMenu();
			break;
		case 2:
			displayRechargeDetails();//........on entering 2 the user will be able to view the previous Recharge-Details
			displayMenu();
			break;
		case 3:
			System.exit(0);      //.............on entering 3 the User will be able to exit from Application.
		default:
			throw new InvalidNumberException();
			
		}
	}
	private void displayRechargeDetails() 
	{
		rfh.readFile();//.....................//To display all the details of the successful recharge. 
		
	}
	private void addRechargeDetails() 
	{
			
			System.out.println("Select Recharge Type (Prepaid/Postpaid)");
			String type=scanner.nextLine();
			obj.setRechargeType(type);
			System.out.println("Enter Mobile No.");
			String mobileNo=scanner.nextLine();
			obj.setMobileNo(mobileNo);
			System.out.println("Select Current Operator (Airtel/DoCoMo/BSNL/Jio)");
			String currentOperator=scanner.nextLine();
			obj.setCurrentOperator(currentOperator);
			System.out.println("Enter Amount (Rs)");
			double amount=Math.round(Double.parseDouble(scanner.nextLine()) * 100D) / 100D;
			obj.setAmount(amount);
			
			if(rdv.validateDetails(obj)) 
			{
				System.out.println("Successful Recharge. Transaction ID: "+obj.getTransactionID());
				rfh.fileWrite(obj);//.....................the TransactionId will be displayed
			}
			else
			{
				System.out.println("Failed to recharge.");
			}
	
		
		
	}

}
