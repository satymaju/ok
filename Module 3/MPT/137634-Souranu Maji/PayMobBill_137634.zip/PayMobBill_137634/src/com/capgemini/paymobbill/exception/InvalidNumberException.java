package com.capgemini.paymobbill.exception;

public class InvalidNumberException extends Exception {
	public InvalidNumberException() {
		System.out.println("You have entered Invalid Number.Please Check your Number before provide.");

	}
}

