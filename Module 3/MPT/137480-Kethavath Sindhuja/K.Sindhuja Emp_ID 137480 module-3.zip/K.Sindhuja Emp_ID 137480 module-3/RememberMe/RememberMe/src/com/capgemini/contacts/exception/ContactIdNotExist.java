package com.capgemini.contacts.exception;

public class ContactIdNotExist extends Exception //creating class of ClassId does not exists
{
	public ContactIdNotExist()
	{
		System.out.println("Contact Id not exist");
	}
}
