package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class RechargeFileHelperTestCase {
	
	RechargeFileHelper rfh = new RechargeFileHelper();
	
	RechargeDetails tdata1= new RechargeDetails("Prepaid","Jio","8256756777",309,1435);

	@Test(timeout=50)
	public void testFileWrite() {
		rfh.fileWrite(tdata1);
		
	}

	@Test(timeout=200)
	public void testReadFile() {
		rfh.readFile();
	}

}
