package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeDataValidator;

public class RechargeDataValidatorTestCase {
	
	RechargeDataValidator rdv = new RechargeDataValidator();
	RechargeDetails tdata1= new RechargeDetails("Prepaid","Jio","8256756777",309,1435);
	RechargeDetails tdata2= new RechargeDetails("Prepaid","Jio","8256756777",30954,1435);
	RechargeDetails tdata3= new RechargeDetails("Prepaid","Jio","8256756777",3062,16825);
	RechargeDetails tdata4= new RechargeDetails("Pre","Jio","8256756777",3062,16825);
	
	@Test
	public void testValidateDetails() {
		assertEquals(true,rdv.validateDetails(tdata1));
	}
	
	@Test
	public void testValidateDetails2() {
		assertEquals(false,rdv.validateDetails(tdata2));
	}
	
	@Test
	public void testValidateDetails3() {
		assertEquals(false,rdv.validateDetails(tdata3));
	}
	
	@Test
	public void testValidateRechargeType() {
		assertEquals(true,rdv.validateRechargeType(tdata1));
	}
	
	@Test
	public void testValidateRechargeType2() {
		assertEquals(false,rdv.validateRechargeType(tdata4));
	}

}
