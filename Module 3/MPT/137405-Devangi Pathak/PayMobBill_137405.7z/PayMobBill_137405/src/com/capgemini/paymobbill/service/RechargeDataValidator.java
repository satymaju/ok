package com.capgemini.paymobbill.service;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeDataValidator {

	public boolean validateDetails(RechargeDetails pru)
	{
		if(validateRechargeType(pru) && validateMobileNo(pru) && validateCurrentOperator(pru) && validateAmount(pru) && validateTransactionID(pru))
		{
			return true;
			
		}
		else
		{
			return false;
		}
	}
	
	
	private boolean validateAmount(RechargeDetails pru)
	{
		double amount=pru.getAmount();
		try {
			if(amount>=10 && amount<=9999)
			{
				return true;
			}
			else
			{
				return false;
			}
		}catch(NumberFormatException nfe) {
			System.out.println("Please Enter currect amount");
			return false;
		}
	}
	
	private boolean validateTransactionID(RechargeDetails pru) 
	{
		String transactionID= Integer.toString(pru.getTransactionID());
		if(transactionID.matches("[0-9]{4}")) {
			return true;
		}else {
			return false;
		}
		
	}
	
	private boolean validateMobileNo(RechargeDetails pru) 
	{
		String MobileNo=pru.getMobileNo();
		if(MobileNo.matches("[7-9][0-9]{9}"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	private boolean validateCurrentOperator(RechargeDetails pru)
	{
		String x = pru.getCurrentOperator().toLowerCase();
		String y = pru.getCurrentOperator().toLowerCase();
		String z = pru.getCurrentOperator().toLowerCase();
		String a = pru.getCurrentOperator().toLowerCase();
		if(x.equals("airtel") ||  y.equals("bsnl") || z.equals("docomo")|| a.equals("jio"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	
	public boolean validateRechargeType(RechargeDetails pru)
	{
		if(pru.getRechargeType().toLowerCase().equals("prepaid") || pru.getRechargeType().toLowerCase().equals("postpaid"))
		{
			return true;
		}
		else 
		{
			return false;
		}
	}


}
