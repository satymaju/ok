package com.capgemini.paymobbill.service;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeDataValidator {

	public boolean validateDetails(RechargeDetails pru)
	{
		if(validateRechargeType(pru) && validateMobileNo(pru) && validateCurrentOperator(pru) && validateAmount(pru))
		{
			return true;
			
		}
		else
		{
			return false;
		}
	}
	
	public boolean validateAmount(RechargeDetails pru)
	{
		double amount=pru.getAmount();
		 
			if(amount>=10 && amount<=9999)
			{
				return true;
			}
			else
			{
				System.out.println("Amount should be minimum Rs10 and maximum Rs9999\n");
				return false;
			}
		
	}
	public boolean validateCurrentOperator(RechargeDetails pru)
	{
		String x = pru.getCurrentOperator().toLowerCase();
		String y = pru.getCurrentOperator().toLowerCase();
		String z = pru.getCurrentOperator().toLowerCase();
		String a = pru.getCurrentOperator().toLowerCase();
		if(x.equals("airtel") ||  y.equals("bsnl") || z.equals("docomo")|| a.equals("jio"))
		{
			return true;
		}
		else
		{
			System.out.println("Error at operator name.\n");
			return false;
		}
	}
	public boolean validateMobileNo(RechargeDetails pru) 
	{
		String MobileNo=pru.getMobileNo();
		if(MobileNo.matches("[7-9][0-9]{9}"))
		{
			return true;
		}
		else
		{
			System.out.println("Mobile number not valid.\n");
			return false;
		}
	}
	public boolean validateRechargeType(RechargeDetails pru)
	{
		if(pru.getRechargeType().toLowerCase().equals("prepaid") || pru.getRechargeType().toLowerCase().equals("postpaid"))
		{
			return true;
		}
		System.out.println("Error at Recharge type.\n");
		return false;
	}

}
