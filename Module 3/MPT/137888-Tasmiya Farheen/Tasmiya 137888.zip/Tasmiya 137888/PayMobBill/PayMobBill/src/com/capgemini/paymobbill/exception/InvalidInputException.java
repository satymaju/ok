package com.capgemini.paymobbill.exception;

public class InvalidInputException extends Exception {
	@Override
	public String getMessage()  
	{
		return "Please enter valid data.\n";
	}
}
