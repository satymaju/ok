package com.capgemini.paymobbill.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;

class RechargeDataValidatorTest {
	RechargeDetails obj = new RechargeDetails("postpaid","airtel","9573829693",10999d,1234);
	RechargeDataValidator rdv = new RechargeDataValidator();
	@Test
	void testValidateDetails() {
		assertEquals(true, rdv.validateRechargeType(obj));
	}

//	@Test
//	void testValidateRechargeType() {
//		fail("Not yet implemented");
//	}
}
