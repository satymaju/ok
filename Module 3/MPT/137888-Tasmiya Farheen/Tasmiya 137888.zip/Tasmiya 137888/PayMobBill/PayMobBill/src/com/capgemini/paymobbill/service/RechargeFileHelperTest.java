package com.capgemini.paymobbill.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;

class RechargeFileHelperTest {
	RechargeFileHelper ob=new RechargeFileHelper();
	RechargeDetails obj = new RechargeDetails("postpaid","airtel","9573829693",1999d,1234);
	@Test
	void testFileWrite() {
		assertEquals(true,ob.fileWrite(obj,"D:/abc.txt"));
	}

	@Test
	void testReadFile() {
		assertEquals(true,ob.readFile("D:/abc.txt"));
	}

}
