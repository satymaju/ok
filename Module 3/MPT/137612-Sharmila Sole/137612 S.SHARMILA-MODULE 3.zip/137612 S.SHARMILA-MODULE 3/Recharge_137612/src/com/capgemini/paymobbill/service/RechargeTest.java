package com.capgemini.paymobbill.service;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeTest {
		RechargeDetails obj = new RechargeDetails("prepaid","jio","9701372820",10999d,1234);
		RechargeDataValidator rdv = new RechargeDataValidator();
		@Test
		public void testValidateDetails() {
			assertEquals(true, rdv.validateRechargeType(obj));
		}

}
