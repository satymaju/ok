package com.capgemini.paymobbill.service;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeDataValidator {

	public boolean validateDetails(RechargeDetails s)
	{
		if(validateRechargeType(s) && validateMobileNo(s) && validateCurrentOperator(s) && validateAmount(s))
		{
			return true;
			
		}
		else
		{
			return false;
		}
	}
	
	public boolean validateAmount(RechargeDetails s)
	{
		double amount=s.getAmount();
		 
			if(amount>=10 && amount<=9999)
			{
				return true;
			}
			else
			{
				System.out.println("Amount should be in the range between 10 and 9999\n");
				return false;
			}
		
	}
	public boolean validateCurrentOperator(RechargeDetails s)
	{
		String x = s.getCurrentOperator().toLowerCase();
		String y = s.getCurrentOperator().toLowerCase();
		String z = s.getCurrentOperator().toLowerCase();
		String a = s.getCurrentOperator().toLowerCase();
		if(x.equals("airtel") ||  y.equals("bsnl") || z.equals("docomo")|| a.equals("jio"))
		{
			return true;
		}
		else
		{
			System.out.println("Enter Valid Operator Name.\n");
			return false;
		}
	}
	public boolean validateMobileNo(RechargeDetails s) 
	{
		String MobileNo=s.getMobileNo();
		if(MobileNo.matches("[7-9][0-9]{9}"))
		{
			return true;
		}
		else
		{
			System.out.println("Invalid Mobile number.\n");
			return false;
		}
	}
	public boolean validateRechargeType(RechargeDetails s)
	{
		if(s.getRechargeType().toLowerCase().equals("prepaid") || s.getRechargeType().toLowerCase().equals("postpaid"))
		{
			return true;
		}
		System.out.println("Error at Recharge type.\n");
		return false;
	}

}
