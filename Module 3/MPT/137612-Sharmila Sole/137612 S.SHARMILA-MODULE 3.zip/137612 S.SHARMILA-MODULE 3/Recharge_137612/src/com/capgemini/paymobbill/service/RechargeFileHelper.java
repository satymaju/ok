package com.capgemini.paymobbill.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.capgemini.paymobbill.bean.RechargeDetails;


public class RechargeFileHelper
{
	
	public boolean fileWrite(RechargeDetails obj,String path) {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path));
			oos.writeObject(obj);
			oos.close();
			return true;
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return false;
	}

	public boolean readFile(String path) {
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(path));
				System.out.println(ois.readObject());
				ois.close();
				return true;
			} 
			catch (ClassNotFoundException e) {
				System.out.println(e.getMessage());			
			} 
			catch (FileNotFoundException e) {
				System.out.println(e.getMessage());
			} 
			catch (IOException e) {
				System.out.println(e.getMessage());
			}
		return false;
	}
	
	
}


