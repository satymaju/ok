package com.capgemini.paymobbill.service;

import static org.junit.Assert.*;


import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeFileHelperTest {
	
	RechargeFileHelper ob=new RechargeFileHelper();
	RechargeDetails obj = new RechargeDetails("postpaid","airtel","9951961361",1999d,1234);
	@Test
	public void testFileWrite() {
		assertEquals(true,ob.fileWrite(obj,"D:/MobileBill.obj"));
	}

	@Test
	public void testReadFile() {
		assertEquals(true,ob.readFile("D:/MobileBill.obj"));

	}


	

}
