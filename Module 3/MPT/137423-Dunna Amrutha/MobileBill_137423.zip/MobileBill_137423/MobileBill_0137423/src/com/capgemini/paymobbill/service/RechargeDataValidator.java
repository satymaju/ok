package com.capgemini.paymobbill.service;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeDataValidator {
	
	public boolean validateDetails(RechargeDetails obj1)
	{
		if(validateRechargeType(obj1) &&  validateCurrentOperator(obj1) && validateMobileNo(obj1) && validateAmount(obj1))
		{
			return true;
			
		}
		else
		{
			return false;
		}
	}
	
	public boolean validateRechargeType(RechargeDetails obj1)
	{
		if(obj1.getRechargeType().toLowerCase().equals("prepaid") || obj1.getRechargeType().toLowerCase().equals("postpaid"))
		{
			return true;
		}
		System.out.println("Error at Recharge type.\n");
		return false;
	}
	
	
	public boolean validateCurrentOperator(RechargeDetails obj1)
	{
		String a = obj1.getCurrentOperator().toLowerCase();
		String b = obj1.getCurrentOperator().toLowerCase();
		String c = obj1.getCurrentOperator().toLowerCase();
		String d = obj1.getCurrentOperator().toLowerCase();
		if(a.equals("airtel") ||  b.equals("bsnl") || c.equals("docomo")|| d.equals("jio"))
		{
			return true;
		}
		else
		{
			System.out.println("Error at operator name.\n");
			return false;
		}
	}
	
	

	public boolean validateMobileNo(RechargeDetails obj1) 
	{
		String MobileNo=obj1.getMobileNo();
		if(MobileNo.matches("[7-9][0-9]{9}"))
		{
			return true;
		}
		else
		{
			System.out.println("Invalid mobile number.\n");
			return false;
		}
	}
	
	
	public boolean validateAmount(RechargeDetails obj1)
	{
		double amount=obj1.getAmount();
		 
			if(amount>=10 && amount<=9999)
			{
				return true;
			}
			else
			{
				System.out.println("Amount should be in the range between 10 and 9999\n");
				return false;
			}
		
	}

}
