package com.capgemini.paymobbill.ui;

import java.util.Scanner;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.exception.InvalidInputException;
import com.capgemini.paymobbill.service.RechargeDataValidator;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class RechargeClient {
	
	

	Scanner scan = new Scanner(System.in);
	RechargeDetails obj=new RechargeDetails();
	RechargeDataValidator datav=new RechargeDataValidator();
	RechargeFileHelper fileh = new RechargeFileHelper();
	
	String filePath="D:/text.txt";
	
	
	public void displayMenu()
	{
		System.out.println("1.Make a Recharge");
		System.out.println("2.Display Recharge Details");
		System.out.println("3.Exit");
		int option=Integer.parseInt(scan.nextLine());
		switch(option)
		{
		case 1:
			recharge();
			displayMenu();
			break;
		case 2:
			details();
			displayMenu();
			break;
		case 3:
			System.exit(0);
			break;
		default: System.out.println("Choose a valid option\n");
		 		displayMenu();
		}
	}
	
	private void details() 
	{
		fileh.readFile(filePath);
		
	}
	
	private void recharge() 
	{
		try 
		{	
			System.out.println("Select Recharge Type (Prepaid/Postpaid)");
			obj.setRechargeType(scan.nextLine());
			if(!datav.validateRechargeType(obj))
				throw new InvalidInputException(); //throwing userdefined exception
			
			System.out.println("Enter Mobile No.");
			obj.setMobileNo(scan.nextLine());
			if(!datav.validateMobileNo(obj))
				throw new InvalidInputException();
			
			System.out.println("Select Current Operator (Airtel/Docomo/BSNL/Jio)");
			obj.setCurrentOperator(scan.nextLine());
			if(!datav.validateCurrentOperator(obj))
				throw new InvalidInputException();
			System.out.println("Enter Amount (Rs)");
			
			double amount=Math.round(Double.parseDouble(scan.nextLine()));
			obj.setAmount(amount);
			if(!datav.validateAmount(obj))
				throw new InvalidInputException();
				System.out.println("Successful Recharge. Transaction ID: "+obj.getTransactionID());
				fileh.fileWrite(obj,filePath);
			
		}
		catch(NumberFormatException e)
		{
			System.out.println("only numbers are allowed. \nError at: "+e.getMessage()+"\nFailed to recharge\n");
		}
		catch(InvalidInputException e)  
		{  //handling userdefined exception
			System.out.println("Failed to recharge.");
			System.out.println(e.getMessage());
		}
	}

	public static void main(String[] args) 
	{
		RechargeClient rc = new RechargeClient();
		rc.displayMenu();
	}
}



