package com.capgemini.paymobbill.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeFileHelper {
	
	public boolean fileWrite(RechargeDetails obj,String path) {
		try {
			ObjectOutputStream objo = new ObjectOutputStream(new FileOutputStream(path));
			objo.writeObject(obj);
			objo.close();
			return true;
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return false;
	}

	public boolean readFile(String path) {
		try {
			ObjectInputStream obji = new ObjectInputStream(new FileInputStream(path));
				System.out.println(obji.readObject());
				obji.close();
				return true;
			} 
			catch (ClassNotFoundException e) {
				System.out.println(e.getMessage());			
			} 
			catch (FileNotFoundException e) {
				System.out.println(e.getMessage());
			} 
			catch (IOException e) {
				System.out.println(e.getMessage());
			}
		return false;
	}
	

}
