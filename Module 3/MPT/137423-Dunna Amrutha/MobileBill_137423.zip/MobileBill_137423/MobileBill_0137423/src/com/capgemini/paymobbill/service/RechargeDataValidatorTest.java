package com.capgemini.paymobbill.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeDataValidatorTest {

	RechargeDetails obj = new RechargeDetails("postpaid","9502191296","airtel",1099d,2000);
	RechargeDataValidator datav = new RechargeDataValidator();
	@Test
	void testValidateDetails() {
		assertEquals(true, datav.validateRechargeType(obj));
	}
	private void assertEquals(boolean b, boolean validateRechargeType) {
		
	}
} 
