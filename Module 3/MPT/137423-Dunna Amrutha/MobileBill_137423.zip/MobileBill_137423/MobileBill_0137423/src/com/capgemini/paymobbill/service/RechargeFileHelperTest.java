package com.capgemini.paymobbill.service;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeFileHelperTest {
	
	RechargeFileHelper ob=new RechargeFileHelper();
	RechargeDetails obj = new RechargeDetails("postpaid","9502191296","airtel",1209d,2000);
	@Test
	void testFileWrite() {
		assertEquals(true,ob.fileWrite(obj,"D:/text.txt"));
	}

	@Test
	void testReadFile() {
		assertEquals(true,ob.readFile("D:/text.txt"));
	}

	private void assertEquals(boolean b, boolean readFile) {
		
		
	}

}
