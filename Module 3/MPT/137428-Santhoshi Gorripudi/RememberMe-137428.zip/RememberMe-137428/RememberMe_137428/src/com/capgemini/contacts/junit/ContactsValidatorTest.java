package com.capgemini.contacts.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class ContactsValidatorTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
