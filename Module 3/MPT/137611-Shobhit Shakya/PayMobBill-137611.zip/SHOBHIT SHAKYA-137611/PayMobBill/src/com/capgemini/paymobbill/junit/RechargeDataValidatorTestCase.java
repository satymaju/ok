package com.capgemini.paymobbill.junit;   								// NAME OF PACKAGE

import static org.junit.Assert.*;																
import org.junit.Test;													// NECESSARY IMPORTS 		
import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeDataValidator;

public class RechargeDataValidatorTestCase {							// CLASS RECHARGEDATAVALIDATORTESTCASE
	
	RechargeDataValidator RdV = new RechargeDataValidator();								// CREATING THE OBJECT
	RechargeDetails tdata1= new RechargeDetails("prepaid","jio","7985019957",399,1234);
	RechargeDetails tdata2= new RechargeDetails("prepaid","jio","7985019957",30879,1234);	// ENTERING THE DATA
	RechargeDetails tdata3= new RechargeDetails("prepaid","jio","7985019957",3087,19234);
	RechargeDetails tdata4= new RechargeDetails("pre","jio","7985019957",3087,19234);
	
	public void testValidateDetails() {														// METHOD TO CHECK THE ENTERED DATA
		assertEquals(true,RdV.validateDetails(tdata1));
	}
	
	
	public void testValidateDetails2() {													// METHOD TO CHECK THE ENTERED DATA
		assertEquals(false,RdV.validateDetails(tdata2));
	}
	
	
	public void testValidateDetails3() {
		assertEquals(false,RdV.validateDetails(tdata3));									// METHOD TO CHECK THE ENTERED DATA
	}
	
	
	public void testValidateRechargeType() { 											    //METHOD TO CHECK THE ENETERED DATA 
		assertEquals(true,RdV.validateRechargeType(tdata1));
	}
	
	
	public void testValidateRechargeType2() {												// METHOD TO CHECK THE ENTERED DATA
		assertEquals(false,RdV.validateRechargeType(tdata4));
	}

}
