package com.capgemini.paymobbill.bean;                     // PACKAGE NAME 

import java.io.Serializable;                               // NECESSARY IMPORTS	

public class RechargeDetails implements Serializable{      // RECHARGE DETAILS CLASS IMPLEMENTING SERIALIZABLE
	String rechargeType;                                   
	String currentOperator;                                
	String mobileNo;                                       // INSERTING THE MANDATORY DETAILS ABOUT THE RECHARGE
	double amount;
	int transactionID;

	public RechargeDetails() {                                // CONSTRUCTOR OF CLASS RECHARGEDETAILS
		this.transactionID = (int)(Math.random()*9000)+1000;  // GENERATING THE RANDOM TRANSACTION ID 
	}
	public String getRechargeType() {                        // METHOD TO ASK THE RECHARGE TYPE
		return rechargeType;
	}
	public void setRechargeType(String rechargeType) {       // METHOD TO SET THE RECHARGE TYPE
		this.rechargeType = rechargeType;
	}
	public String getCurrentOperator() {                     // METHOD TO ASK THE OPERATOR NAME
		return currentOperator;
	}
	public void setCurrentOperator(String currentOperator) {  // METHOD TO SET THE OPERATOR NAME
		this.currentOperator = currentOperator;
	}
	public String getMobileNo() {                             // METHOD TO ASK THE MOBILE NUMBER	
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {                // METHOD TO GET THE MOBILE NUMBER 
		this.mobileNo = mobileNo;
	}
	public double getAmount() {                              // METHOD TO ASK THE AMOUNT OF RECHARGE
		return amount;
	}
	public void setAmount(double amount) {                  // METHOD TO GET THE AMOUNT OF RECHARGE
		this.amount = amount;
	}
	public int getTransactionID() {    						// METHOD TO GET THE TRANSACTION ID
		return transactionID;
	}
	
	public RechargeDetails(String rechargeType, String currentOperator, String mobileNo, double amount,
			int transactionID) {                   // METHOD TO ASSIGN THE DETAILS TO DIFFERENT MANDATORY FIELDS INSIDE THE CLASS
		super();
		this.rechargeType = rechargeType;
		this.currentOperator = currentOperator;
		this.mobileNo = mobileNo;                   // ASSIGNING VALUES TO MANDATORY FIELDS   
		this.amount = amount;
		this.transactionID = transactionID;
	}
	public String toString() {                          // METHOD TO SHOW THE OUTPUT DETAILS ON THE DISPLAY SCREEN
		return "RechargeDetails [rechargeType=" + rechargeType + ", currentOperator=" + currentOperator + ", mobileNo="
				+ mobileNo + ", amount=" + amount + ", transactionID=" + transactionID + "]";
	}
	
}
