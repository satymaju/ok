package com.capgemini.contacts.exception;

public class ContactId extends Exception {
	public ContactId(){
		System.out.println("Contact Id not exist");
	}
}
