package com.capgemini.contacts.service;

import com.capgemini.contacts.bean.ContactDetails;
import com.capgemini.contacts.dao.ClientDao;
import com.capgemini.contacts.exception.ContactId;
import com.capgemini.contacts.exception.ContactName;

public class ContactsHelper {
	static ClientDao dao = new ClientDao();
	public void addContactDetails(ContactDetails contactDetails){
		try {
			dao.addToList(contactDetails);
		} catch (ContactName e) {
			// TODO Auto-generated catch block
		}
	}
	public void deleteContactDetails(int contactID){
		try {
			dao.removeFromList(contactID);
		} catch (ContactId e) {
			// TODO Auto-generated catch block
			
		}
	}
	
	static{
		try {
			dao.addToList(new ContactDetails(1,"Kirti Roy","9234534500",null,"kirtiroy@yahoo.co.in","FAMILY"));
		} catch (ContactName e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			dao.addToList(new ContactDetails(2,"Raj Singh","8288866678","8234343434","Arun16@gmail.com","FRIENDS"));
		} catch (ContactName e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
