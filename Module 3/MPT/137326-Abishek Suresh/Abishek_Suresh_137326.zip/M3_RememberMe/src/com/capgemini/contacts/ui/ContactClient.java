package com.capgemini.contacts.ui;

import java.util.Scanner;

import com.capgemini.contacts.bean.ContactDetails;
import com.capgemini.contacts.service.ContactsHelper;
import com.capgemini.contacts.service.ContactsValidator;

public class ContactClient {
	static Scanner scan = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ContactClient client = new ContactClient();
		client.display();
	}
	
	//***************************USER INPUT**************************//
		public static ContactDetails InputUser(){
			ContactDetails obj2 = new ContactDetails();
		
			System.out.println("Enter Name : ");
			obj2.setcName(scan.nextLine());
			System.out.println("Enter Mobile No.: ");
			obj2.setMobileNo1(scan.nextLine());
			System.out.println("Do you want to add alternate Mobile No. ? ");
			
			char op;
			op = scan.nextLine().charAt(0);
			if(op=='Y' || op=='y')
			{
				System.out.println("Enter Mobile No. : ");
				obj2.setMobileNo2(scan.nextLine());
			}
			else{
				obj2.setMobileNo2(null);
			}
			System.out.println("Enter Email ID : ");
			obj2.setEmailID(scan.nextLine());
			
			System.out.println("Select the Group (Friends / Family / CoWorkers) : ");
			String group=scan.nextLine().toUpperCase();
			obj2.setGroupName(group);
			
			return obj2;
		}
		
	//***************************MENU DISPLAY**************************//
	public void display(){
		int option;
		boolean flag=false;
		ContactsValidator obj1 = new ContactsValidator(); 
		ContactDetails obj2 = new ContactDetails();
		ContactsHelper obj3 = new ContactsHelper();
		while(true)
		{
			System.out.println("**********REMEMBER ME**********");
			System.out.println("MAIN MENU");
			System.out.println("Please choose an option :");
			System.out.println("1. Add New Contact");
			System.out.println("2. Delete Contact");
			System.out.println("3. Exit");
			try {
				option=Integer.parseInt(scan.nextLine());
			
			
			switch(option){
			case 1:
				do{
					System.out.println("Enter the Details:");
					obj2= InputUser();
					flag=obj1.validateDetails(obj2);
					if(!flag){
						System.out.println("Invalid Details. Please Enter the Correct Details...");
					}
				}
				while(flag==false);
				obj3.addContactDetails(obj2);
				break;
			case 2:
				System.out.println("Enter your Contact ID : ");
				int contactID = Integer.parseInt(scan.nextLine());
				obj3.deleteContactDetails(contactID);
				break;
			case 3:
				System.out.println("Terminating the Application....");
				System.exit(0);
			default: 
				System.out.println("Invalid Option.....");
			}
			} 
			catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				System.out.println("Please enter a valid option");
			}
			}
		}
	
}

