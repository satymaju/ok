package com.capgemini.contacts.exception;

public class ContactName extends Exception {
	public ContactName(){
		System.out.println("Duplicate Contact. Failed to add the Contact");
	}
}
