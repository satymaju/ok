package com.capgemini.contacts.dao;

import java.util.ArrayList;
import java.util.Iterator;

import com.capgemini.contacts.bean.ContactDetails;
import com.capgemini.contacts.exception.ContactId;
import com.capgemini.contacts.exception.ContactName;
import com.capgemini.contacts.ui.ContactClient;

public class ClientDao {
	static ArrayList al = new ArrayList();
	public void addToList (ContactDetails obj2)
	throws ContactName
	{
		boolean flag1= false;
		Iterator it = al.iterator();
		while(it.hasNext()){
			ContactDetails cd=(ContactDetails) it.next();
			if(cd.getcName().equals(obj2.getcName())){
				flag1=true;
				throw new ContactName();
			}
		}
		if(flag1==false){
			
			try {
				al.add(obj2);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("Failed to add the contact");
			}
			System.out.println("Contact Added");
			System.out.println("Contact ID is: " + obj2.getContactID() );
		}
	
	}
	
	
	
	public void removeFromList(int contactID) throws ContactId{
		Iterator it = al.iterator();
		boolean flag1=false;
		int i=0;
		while(it.hasNext()){
			ContactDetails cd=(ContactDetails) it.next();
			if(cd.getContactID()==contactID){
				al.remove(cd);
				flag1=true;
				System.out.println("Contact deleted successfully");
				break;
			}
			i++;
		}
		if(!flag1){
			throw new ContactId();
		}
		
	}
}
