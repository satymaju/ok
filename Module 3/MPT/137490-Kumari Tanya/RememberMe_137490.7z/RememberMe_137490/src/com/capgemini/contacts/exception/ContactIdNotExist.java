package com.capgemini.contacts.exception;

public class ContactIdNotExist extends Exception {
	public ContactIdNotExist(){
		System.out.println("Contact Id does not exist");
	}
}