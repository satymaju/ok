package com.capgemini.paymobbill.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.exception.FailedToRechargeException;

public class PmbDao {
	//function to write data to file
		public void writeToFile(List list) throws FailedToRechargeException {
			try {
				ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("resources/MobileBill.obj"));
				oos.writeObject(list);
				oos.close();
			} catch (FileNotFoundException e) {
				throw new FailedToRechargeException();
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
		}
		//fuction to read data from file
		public Object readFromFile() {
			try {
				ObjectInputStream ois = new ObjectInputStream(new FileInputStream("resources/MobileBill.obj"));
				try {
					Object obj=ois.readObject();
					ois.close();
					return obj;
				} catch (ClassNotFoundException e) {
					System.out.println(e.getMessage());			}
			} catch (FileNotFoundException e) {
				System.out.println(e.getMessage());
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
			return null;
			
		}
}
