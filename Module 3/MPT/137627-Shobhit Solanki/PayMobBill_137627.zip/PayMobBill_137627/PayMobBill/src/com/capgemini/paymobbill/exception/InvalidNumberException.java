package com.capgemini.paymobbill.exception;

public class InvalidNumberException extends Exception {
	//constructor to print its details
	public InvalidNumberException() {
		System.out.println("You have enterred Invalid Number");

	}
}
