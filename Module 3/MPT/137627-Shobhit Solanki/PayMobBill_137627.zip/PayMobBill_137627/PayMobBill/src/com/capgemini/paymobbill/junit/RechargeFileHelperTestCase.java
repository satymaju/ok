package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.dao.PmbDao;
import com.capgemini.paymobbill.exception.FailedToRechargeException;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class RechargeFileHelperTestCase {

	RechargeFileHelper rfh = new RechargeFileHelper();
	PmbDao daoObj = new PmbDao();
	RechargeDetails tdata1= new RechargeDetails("prepaid","jio","7014995614",369,9120);
	
	//testing that on writing and after reading object returned is not null
	@Test(timeout=50)
	public void testAddRechargeDetails() throws FailedToRechargeException {
		rfh.addRechargeDetails(tdata1);
		assertNotEquals(null,daoObj.readFromFile());
	}
	//performance testing
	@Test(timeout=50)
	public void testDisplayRechargeDetails() {
		rfh.displayRechargeDetails();
	}

}
