package com.capgemini.paymobbill.service;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeDataValidator {
	
	//function to validate all the details 
	public boolean validateDetails(RechargeDetails rd)
	{
		if(validateRechargeType(rd) & validateMobileNo(rd) & validateCurrentOperator(rd) & validateAmount(rd) & validateTransactionID(rd))
		{
			return true;
			
		}
		else
		{
			return false;
		}
	}
	
	//function to validate transactionID
	private boolean validateTransactionID(RechargeDetails rd) 
	{
		String transactionID= Integer.toString(rd.getTransactionID());
		if(transactionID.matches("[0-9]{4}")) {
			return true;
		}else {
			
			return false;
		}
		
	}
	//function to validate Amount entered by the user
	private boolean validateAmount(RechargeDetails rd)
	{
		double amount=rd.getAmount();
		try {
			if(amount>=10 && amount<=9999)
			{
				return true;
			}
			else
			{	
				System.out.println("Please Enter valid amount in the range of 2 digit to 4 digit");
				return false;
			}
		}catch(NumberFormatException nfe) {
			System.out.println("Please Enter currect amount");
			return false;
		}
	}
	
	//function to validate Current mobile operator
	private boolean validateCurrentOperator(RechargeDetails rd)
	{
		String x = rd.getCurrentOperator().toLowerCase();
		String y = rd.getCurrentOperator().toLowerCase();
		String z = rd.getCurrentOperator().toLowerCase();
		String a = rd.getCurrentOperator().toLowerCase();
		if(x.equals("airtel") ||  y.equals("bsnl") || z.equals("docomo")|| a.equals("jio"))
		{
			return true;
		}
		else
		{	
			System.out.println("Please enter valid current operator");
			return false;
		}
	}
	
	//function to validate mobile number
	private boolean validateMobileNo(RechargeDetails rd) 
	{
		String MobileNo=rd.getMobileNo();
		if(MobileNo.matches("[7-9][0-9]{9}"))
		{
			return true;
		}
		else
		{
			System.out.println("Please enter valid Mobile Number.");
			return false;
		}
	}
	
	//function to validate recharge type
	public boolean validateRechargeType(RechargeDetails rd)
	{
		if(rd.getRechargeType().toLowerCase().equals("prepaid") || rd.getRechargeType().toLowerCase().equals("postpaid"))
		{
			return true;
		}
		else 
		{
			System.out.println("Please enter valid recharge type");
			return false;
		}
	}


}
