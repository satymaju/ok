package com.capgemini.paymobbill.ui;

import java.security.Provider.Service;
import java.util.Scanner;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.exception.FailedToRechargeException;
import com.capgemini.paymobbill.exception.InvalidNumberException;
import com.capgemini.paymobbill.service.RechargeDataValidator;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class RechargeClient {
	Scanner scanner = new Scanner(System.in);
	RechargeDataValidator rdv=new RechargeDataValidator();
	RechargeFileHelper rfh = new RechargeFileHelper();
	
	public static void main(String[] args) {
		RechargeClient rc = new RechargeClient();
		try {
			rc.displayMenu();
		} catch (InvalidNumberException e) {
			
			
		}
	}
	
	//Function to display the user menu
	public void displayMenu() throws InvalidNumberException
	{
		while(true){
			System.out.println("Please Enter your Choice:");
			System.out.println("1.Make a Recharge");
			System.out.println("2.Display Recharge Details");
			System.out.println("3.Exit");
			int choice;
			try{
				choice=Integer.parseInt(scanner.nextLine());
			}catch(NumberFormatException nfe){
				throw new InvalidNumberException();
			}
			switch(choice)
			{
			case 1:
				try {
					recharge();
				} catch (FailedToRechargeException e) {
				}
				break;
			case 2:
				displayDetails();
				break;
			case 3:
				System.exit(0);
			default:
				throw new InvalidNumberException();
				
			}
		}
		
	}
	
	//function to call service class's function to read data from file
	private void displayDetails() 
	{
		rfh.displayRechargeDetails();
		
	}
	
	//function to make a Recharge
	private void recharge() throws FailedToRechargeException 
	{
			RechargeDetails rdObj=new RechargeDetails();
			System.out.print("\nSelect Recharge Type (Prepaid/Postpaid): ");
			String type=scanner.nextLine();
			rdObj.setRechargeType(type);
			System.out.print("Enter Mobile No.: ");
			String mobileNo=scanner.nextLine();
			rdObj.setMobileNo(mobileNo);
			System.out.print("Select Current Operator (Airtel/Docomo/BSNL/Jio): ");
			String currentOperator=scanner.nextLine();
			rdObj.setCurrentOperator(currentOperator);
			System.out.print("Enter Amount (Rs): ");
			
			double amount=0;
			try {
				amount = Math.round(Double.parseDouble(scanner.nextLine()));
			} catch (NumberFormatException e) {
				System.out.println("Please enter valid amount");
			}
			rdObj.setAmount(amount);
			
			//Writing object to file on Validation of data
			if(rdv.validateDetails(rdObj)) 
			{
				System.out.println("Successful Recharge. Transaction ID: "+rdObj.getTransactionID()+"\n");
				rfh.addRechargeDetails(rdObj);
			}
			else
			{
				throw new FailedToRechargeException();
				
			}
	
		
		
	}

}
