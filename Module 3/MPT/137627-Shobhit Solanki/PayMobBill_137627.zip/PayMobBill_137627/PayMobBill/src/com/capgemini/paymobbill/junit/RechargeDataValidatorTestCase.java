package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeDataValidator;

public class RechargeDataValidatorTestCase {
	
	RechargeDataValidator rdv = new RechargeDataValidator();
	RechargeDetails tdata1= new RechargeDetails("prepaid","jio","9413745417",309,1234);
	RechargeDetails tdata2= new RechargeDetails("prepaid","jio","9413745417",30879,1234);
	RechargeDetails tdata3= new RechargeDetails("prepaid","jio","9413745417",3087,19234);
	RechargeDetails tdata4= new RechargeDetails("pre","jio","9413745417",3087,1923);
	RechargeDetails tdata5= new RechargeDetails("prepaid","xyz","9413745417",3087,1923);
	
	//testing with correct details
	@Test
	public void testValidateDetails() {
		assertEquals(true,rdv.validateDetails(tdata1));
	}
	 
	//testing with wrong amount (limit exceeded)
	@Test
	public void testValidateDetails2() {
		assertEquals(false,rdv.validateDetails(tdata2));
	}
	
	//testing with wrong id length
	@Test
	public void testValidateDetails3() {
		assertEquals(false,rdv.validateDetails(tdata3));
	}
	//testing with wrong operator
	@Test
	public void testValidateDetails4() {
		assertEquals(false,rdv.validateDetails(tdata5));
	}
	
	//Validating recharge type function with correct data
	@Test
	public void testValidateRechargeType() {
		assertEquals(true,rdv.validateRechargeType(tdata1));
	}
	
	//testing with incorrect recharge type
	@Test
	public void testValidateRechargeType2() {
		assertEquals(false,rdv.validateRechargeType(tdata4));
	}

}
