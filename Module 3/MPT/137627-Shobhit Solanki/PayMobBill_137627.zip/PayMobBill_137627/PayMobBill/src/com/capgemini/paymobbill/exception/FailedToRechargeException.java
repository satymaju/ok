package com.capgemini.paymobbill.exception;

public class FailedToRechargeException extends Exception {
	
	//constructor to print its details
	public FailedToRechargeException() {
		System.out.println("Failed to recharge.");
	}
	
}
