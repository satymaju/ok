package com.capgemini.paymobbill.bean;

import java.io.Serializable;
import java.util.Random;

public class RechargeDetails implements Serializable{
	String rechargeType;
	String currentOperator;
	String mobileNo;
	double amount;
	int transactionID;
	
	//Constructor to initialize RechargeDetails object with random transaction ID of 4 digits
	public RechargeDetails() {
		Random rand = new Random();
		this.transactionID = rand.nextInt(10000);
	}
	//Getter function to get the value of rechargeType
	public String getRechargeType() {
		return rechargeType;
	}
	//setter function to set the value of rechargeType
	public void setRechargeType(String rechargeType) {
		this.rechargeType = rechargeType;
	}
	//Getter function to get the value of currentOperator
	public String getCurrentOperator() {
		return currentOperator;
	}
	//setter function to set the value of currentOperator
	public void setCurrentOperator(String currentOperator) {
		this.currentOperator = currentOperator;
	}
	//getter function to get the value of mobileNo
	public String getMobileNo() {
		return mobileNo;
	}
	//setter function to set the value of mobileNo
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	//getter function to get the value of amount
	public double getAmount() {
		return amount;
	}
	//setter function to set the value of amount
	public void setAmount(double amount) {
		this.amount = amount;
	}
	//getter function to get the value of transactionID
	public int getTransactionID() {
		return transactionID;
	}
	
	//Constructor to initialize recahrgeDetails object
	public RechargeDetails(String rechargeType, String currentOperator, String mobileNo, double amount,
			int transactionID) {
		super();
		this.rechargeType = rechargeType;
		this.currentOperator = currentOperator;
		this.mobileNo = mobileNo;
		this.amount = amount;
		this.transactionID = transactionID;
	}
	//Overridden method toString to print object details
	@Override
	public String toString() {
		return " TransactionID=" + transactionID + ", Recharge Type=" + rechargeType + ", Current Operator=" + currentOperator + ", Mobile No.="
				+ mobileNo + ", Amount=" + amount + "";
	}
	
}
