package com.capgemini.paymobbill.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.dao.PmbDao;
import com.capgemini.paymobbill.exception.FailedToRechargeException;

public class RechargeFileHelper
{
	static List list = new ArrayList();
	//function to add recharge details to static array list
	public void addRechargeDetails(RechargeDetails rechargeDetails){
		PmbDao daoObj = new PmbDao();
		
		list.add(rechargeDetails);
		try {
			daoObj.writeToFile(list);
		} catch (FailedToRechargeException e) {
			//Exception displays the error in its constructor
		}
	}
	//function to get list object form file to print its details 
	public void displayRechargeDetails(){
		PmbDao daoObj = new PmbDao();
		List templist = new ArrayList(); 
		templist= (List)daoObj.readFromFile();
		System.out.println("\nRecharge Details are:");
		Iterator it = templist.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
		System.out.println("\n");
	}	
}
