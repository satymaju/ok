package com.capgemini.paymobbill.service;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeDataValidator {

	public boolean validateDetails(RechargeDetails cat)
	{
		if(validateRechargeType(cat) && validateMobileNo(cat) && validateCurrentOperator(cat) && validateAmount(cat) && validateTransactionID(cat))
		{
			return true;
			
		}
		else
		{
			return false;
		}
	}
	private boolean validateTransactionID(RechargeDetails cat) 
	{
		String transactionID= Integer.toString(cat.getTransactionID());
		if(transactionID.matches("[0-9]{4}")) {
			return true;
		}else {
			return false;
		}
		
	}
	private boolean validateAmount(RechargeDetails cat)
	{
		double amount=cat.getAmount();
		
			if(amount>=10 && amount<=9999)
			{
				return true;
			}
			else
			{
				
				System.out.println("Please enter correct amount");
				return false;
			}
		
	}
	private boolean validateCurrentOperator(RechargeDetails cat)
	{
		String x = cat.getCurrentOperator().toLowerCase();
		String y = cat.getCurrentOperator().toLowerCase();
		String z = cat.getCurrentOperator().toLowerCase();
		String a = cat.getCurrentOperator().toLowerCase();
		if(x.equals("airtel") ||  y.equals("bsnl") || z.equals("docomo")|| a.equals("jio"))
		{
			return true;
		}
		else
		{
			System.out.println("Please enter valid current operator name.");
			return false;
		}
	}
	private boolean validateMobileNo(RechargeDetails cat) 
	{
		
		String MobileNo=cat.getMobileNo();
		
		if(MobileNo.matches("[7-9][0-9]{9}"))
		{
			return true;
		}
		else
		{
			System.out.println("Please enter valid mobile number");
			return false;
		}
	}
	public boolean validateRechargeType(RechargeDetails cat)
	{
		if(cat.getRechargeType().toLowerCase().equals("prepaid") || cat.getRechargeType().toLowerCase().equals("postpaid"))
		{
			return true;
		}
		else 
		{
			System.out.println("Please enter a valid recharge type.");
			return false;
		}
	}

}
