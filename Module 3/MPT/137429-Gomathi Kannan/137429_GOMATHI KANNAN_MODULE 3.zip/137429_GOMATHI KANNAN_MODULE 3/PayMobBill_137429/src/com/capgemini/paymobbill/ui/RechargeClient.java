package com.capgemini.paymobbill.ui;

//import java.security.Provider.Service;
import java.util.Scanner;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.exception.InvalidNumberException;
import com.capgemini.paymobbill.service.RechargeDataValidator;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class RechargeClient {
	Scanner scanner = new Scanner(System.in);
	RechargeDetails det=new RechargeDetails();
	RechargeDataValidator rdv=new RechargeDataValidator();
	RechargeFileHelper rfh = new RechargeFileHelper();
	public static void main(String[] args) {
		RechargeClient rc = new RechargeClient();
		try {
			rc.displayMenu();
		} catch (InvalidNumberException e) {
			
			
		}
	}
	//Code to display the menu
	public void displayMenu() throws InvalidNumberException
	{
		System.out.println("1.Make a Recharge");
		System.out.println("2.Display Recharge Details");
		System.out.println("3.Exit");
		int option;
		
			option=Integer.parseInt(scanner.nextLine());
		
		switch(option)
		{
		case 1:
			recharge();
			displayMenu();
			break;
		case 2:
			displayDetails();
			//details();
			displayMenu();
			break;
		case 3:
			System.exit(0);
			break;
		default:
			throw new InvalidNumberException();
			
		}
	}
	//code to display details
	private void displayDetails() {
		    System.out.println("Your details are:");
			System.out.println("Your Recharge Type:"+det.getRechargeType());
			System.out.println("Your MobileNo:"+det.getMobileNo());
			System.out.println("Your Current Operator:"+det.getCurrentOperator());
			System.out.println("Your Recharge amount:"+det.getAmount());
		
	}
	/*private void details() 
	{
		rfh.readFile();
		
	}*/
	private void recharge() 
	{
			
			System.out.println("Select Recharge Type (Prepaid/Postpaid)");
			String type=scanner.nextLine();
			det.setRechargeType(type);
			System.out.println("Enter Mobile No.");
			String mobileNo=scanner.nextLine();
			det.setMobileNo(mobileNo);
			System.out.println("Select Current Operator (Airtel/Docomo/BSNL/Jio)");
			String currentOperator=scanner.nextLine();
			det.setCurrentOperator(currentOperator);
			System.out.println("Enter Amount (Rs)");
			double amount=Math.round(Double.parseDouble(scanner.nextLine()) * 100D) / 100D;
			det.setAmount(amount);
			
			if(rdv.validateDetails(det)) 
			{
				System.out.println("Successful Recharge. Transaction ID: "+det.getTransactionID());
				//rfh.fileWrite(det);
			}
			else
			{
				System.out.println("Failed to recharge.");
			}
	
		
		
	}

}
