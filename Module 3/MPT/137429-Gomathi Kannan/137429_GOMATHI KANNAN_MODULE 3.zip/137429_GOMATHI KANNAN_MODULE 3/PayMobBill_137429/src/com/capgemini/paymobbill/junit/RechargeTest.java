package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeDataValidator;

public class RechargeTest {
	
	RechargeDataValidator rdv = new RechargeDataValidator();
	RechargeDetails value1= new RechargeDetails("prepaid","jio","9828772316",309,1234);
	RechargeDetails value2= new RechargeDetails("prepaid","jio","9828772316",30879,1234);
	RechargeDetails value3= new RechargeDetails("prepaid","jio","9828772316",3087,19234);
	RechargeDetails value4= new RechargeDetails("pre","jio","9828772316",3087,19234);
	@Test
	public void testValidateDetails() {
		assertEquals(true,rdv.validateDetails(value1));
	}
	
	@Test
	public void testValidateDetails2() {
		assertEquals(false,rdv.validateDetails(value2));
	}
	
	@Test
	public void testValidateDetails3() {
		assertEquals(false,rdv.validateDetails(value3));
	}
	
	@Test
	public void testValidateRechargeType() {
		assertEquals(true,rdv.validateRechargeType(value1));
	}
	
	@Test
	public void testValidateRechargeType2() {
		assertEquals(false,rdv.validateRechargeType(value4));
	}

}
	