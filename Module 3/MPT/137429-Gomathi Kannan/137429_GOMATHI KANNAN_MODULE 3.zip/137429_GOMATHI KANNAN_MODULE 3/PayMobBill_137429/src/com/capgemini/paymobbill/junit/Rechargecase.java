package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class Rechargecase {
	
	RechargeFileHelper rfh = new RechargeFileHelper();
	
	RechargeDetails tdata1= new RechargeDetails("prepaid","jio","9828772316",309,1234);

	@Test(timeout=50)
	public void testFileWrite() {
		rfh.fileWrite(tdata1);
		
	}

	@Test(timeout=200)
	public void testReadFile() {
		rfh.readFile();
	}

}
