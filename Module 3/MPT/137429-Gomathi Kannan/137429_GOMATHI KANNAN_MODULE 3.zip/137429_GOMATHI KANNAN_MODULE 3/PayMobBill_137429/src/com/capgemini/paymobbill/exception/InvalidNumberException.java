package com.capgemini.paymobbill.exception;

public class InvalidNumberException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public InvalidNumberException() {
		System.out.println("You have typed an Invalid Number");

	}
}
