package com.capgemini.contacts.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.contacts.service.ContactsValidator;

public class ContactsValidatorTestCase {
	ContactsValidator cv = new ContactsValidator();
	@Test
	public void testInValidateCName() {
		assertEquals(false,cv.validateCName("pra"));
	}
	@Test
	public void testValidateCName() {
		assertEquals(true,cv.validateCName("prateek"));
	}

	@Test
	public void testInValidateMobileNo() {
		assertEquals(false,cv.validateMobileNo("55555"));
	}
	@Test
	public void testValidateMobileNo() {
		assertEquals(true,cv.validateMobileNo("9799191862"));
	}

	@Test
	public void testInValidateEmailID() {
		assertEquals(false,cv.validateEmailID("fyrtjktd"));
	}
	@Test
	public void testValidateEmailID() {
		assertEquals(true,cv.validateEmailID("prateek.mehta@capgemini.com"));
	}

	@Test
	public void testInValidateGroupName() {
		assertEquals(false,cv.validateGroupName("hiyui"));
	}
	@Test
	public void testValidateGroupName() {
		assertEquals(true,cv.validateGroupName("FAMILY"));
	}
}
