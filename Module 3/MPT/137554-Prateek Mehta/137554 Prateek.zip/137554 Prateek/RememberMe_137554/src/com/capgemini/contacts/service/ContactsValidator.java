package com.capgemini.contacts.service;

import java.util.Random;

import com.capgemini.contacts.bean.ContactDetails;

public class ContactsValidator {
	public boolean validateCName(String cName){
		if (cName.matches("[a-zA-Z\\s]{5,15}"))
			return true;
		else
		{
			System.out.println("Please Enter correct name between 5-15 characters.");
			return false;
		}
	}
	public boolean validateMobileNo(String mobileNo){
		if( mobileNo.matches("[7-9][0-9]{9}"))
			return true;
		else
		{
			System.out.println("Please Enter correct Mobile Number.");
			return false;
		}
		
	}
	public boolean validateEmailID(String emailID){
		if(emailID.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$"))
			return true;
		else
		{
			System.out.println("Please Enter Correct E-mail ID.");
			return false;
		}
	}
	public boolean validateGroupName(String groupName){
		if (groupName.matches("FRIENDS|FAMILY|COWORKERS"))
			return true;
		else
		{
			System.out.println("Please Enter Group Name from given choices only.");
			return false;
		}
	}
	public boolean validateDetails(ContactDetails details) {
		
		try {
			ContactsValidator contactValidator = new ContactsValidator();
			if (contactValidator.validateCName(details.getcName())&contactValidator.validateMobileNo(details.getMobileNo1())&contactValidator.validateEmailID(details.getEmailID())&contactValidator.validateGroupName(details.getGroupName())){
				 if(details.getMobileNo2()==null||contactValidator.validateMobileNo(details.getMobileNo2()))
				 {	Random rand = new Random();
				 	details.setContactID(rand.nextInt(10));
				 	return true;
				 }
				 else{
					 return false;
				 }
			}
			else{
				return false;
			}
		} catch (Exception e) {
			System.out.println("Failed to add the Contact.");
			return false;
		}
		
		
	}
}
