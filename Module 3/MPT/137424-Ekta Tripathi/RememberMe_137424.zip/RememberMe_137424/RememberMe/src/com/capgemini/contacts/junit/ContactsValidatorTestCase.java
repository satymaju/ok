package com.capgemini.contacts.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.contacts.service.ContactsValidator;

public class ContactsValidatorTestCase {
	ContactsValidator contactValidator = new ContactsValidator();
	@Test
	public void testValidateCName() {
		assertEquals(false,contactValidator.validateCName("et"));
	}

	@Test
	public void testValidateMobileNo() {
		assertEquals(false,contactValidator.validateMobileNo("41454564564"));
	}

	@Test
	public void testValidateEmailID() {
		assertEquals(false,contactValidator.validateEmailID("etwhbnd"));
	}

	@Test
	public void testValidateGroupName() {
		assertEquals(false,contactValidator.validateGroupName("fndjkjk"));
	}

}
