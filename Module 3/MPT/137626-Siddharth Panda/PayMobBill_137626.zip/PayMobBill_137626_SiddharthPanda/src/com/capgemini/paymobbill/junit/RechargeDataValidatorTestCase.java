package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeDataValidator;

public class RechargeDataValidatorTestCase {
	
	RechargeDataValidator rdv = new RechargeDataValidator();
	RechargeDetails test= new RechargeDetails("Prepaid","JIO","9437306963",100,8765);
	RechargeDetails test2= new RechargeDetails("Postpaid","Airtel","773094661",45738,3456);
	RechargeDetails test3= new RechargeDetails("prepaid","jio","7328094661",1394,23567);
	RechargeDetails test4= new RechargeDetails("post","BSNL","9437306954",1394,23567);
	@Test
	public void testValidateDetails() {
		assertEquals(true,rdv.validateDetails(test));
	}
	
	@Test
	public void testValidateDetails2() {
		assertEquals(false,rdv.validateDetails(test2));
	}
	
	@Test
	public void testValidateDetails3() {
		assertEquals(false,rdv.validateDetails(test3));
	}
	
	@Test
	public void testValidateRechargeType() {
		assertEquals(true,rdv.validateRechargeType(test));
	}
	
	@Test
	public void testValidateRechargeType2() {
		assertEquals(false,rdv.validateRechargeType(test4));
	}

}
