package com.capgemini.paymobbill.exception;

public class InvalidNumberException extends Exception {
	public InvalidNumberException() {
		System.out.println("You have entered an Invalid Option");  //Error message to display when user enters wrong option in SwitchCase
}
}
