package com.capgemini.paymobbill.service;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeDataValidator {

	private boolean validateTransactionID(RechargeDetails rd) 
	{
		String transactionID= Integer.toString(rd.getTransactionID());
		if(transactionID.matches("[0-9]{4}")) {
			return true;
		}else {
			return false;
		}
		
	}
	
	/* Function to validate Current Operator*/
	
	private boolean validateCurrentOperator(RechargeDetails rd)
	{
		String op1 = rd.getCurrentOperator().toLowerCase();
		String op2 = rd.getCurrentOperator().toLowerCase();
		String op3 = rd.getCurrentOperator().toLowerCase();
		String op4 = rd.getCurrentOperator().toLowerCase();
		if(op1.equals("airtel") ||  op2.equals("bsnl") || op3.equals("docomo")|| op4.equals("jio"))  //Current Operator could be Airtel,Docomo,BSNL or Jio
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/* Function to Validate Mobile Number*/
	
	private boolean validateMobileNo(RechargeDetails rd) 
	{
		String MobileNo=rd.getMobileNo();
		if(MobileNo.matches("[7-9][0-9]{9}"))			//Mobile number has to start with 7,8,9 and should consist of 10 digits
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean validateDetails(RechargeDetails rd)
	{
		if(validateRechargeType(rd) && validateMobileNo(rd) && validateCurrentOperator(rd) && validateAmount(rd) && validateTransactionID(rd))
		{
			return true;
			
		}
		else
		{
			return false;
		}
	}
	
	/*Function to validate Amount*/
	
	private boolean validateAmount(RechargeDetails rd)
	{
		double amount=rd.getAmount();
		try {
			if(amount>=10 && amount<=9999)		//Amount can only be minimum 2 digit number and maximum 4 digit number
			{
				return true;
			}
			else
			{
				return false;
			}
		}catch(NumberFormatException nfe) {
			System.out.println("Please Enter currect amount");
			return false;
		}
	}
	
	/* Function to validate Recharge Type*/
	
	public boolean validateRechargeType(RechargeDetails rd)
	{
		if(rd.getRechargeType().toLowerCase().equals("prepaid") || rd.getRechargeType().toLowerCase().equals("postpaid"))
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
	
	
}
