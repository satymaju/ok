package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class RechargeFileHelperTestCase {
	
	RechargeFileHelper rfh = new RechargeFileHelper();
	
	RechargeDetails test= new RechargeDetails("pREPAID","Airtel","9337783456",100,1234);

	@Test(timeout=50)
	public void testFileWrite() {
		rfh.fileWrite(test);
		
	}

	@Test(timeout=200)
	public void testReadFile() {
		rfh.readFile();
	}

}
