package com.capgemini.paymobbill.ui;

import java.util.Scanner;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.exception.InvalidNumberException;
import com.capgemini.paymobbill.service.RechargeDataValidator;
import com.capgemini.paymobbill.service.RechargeFileHelper;


public class RechargeClient {

	Scanner scanner = new Scanner(System.in);
	RechargeDetails obj=new RechargeDetails();                      //Object for RechargeDetails is obj
	RechargeDataValidator obj2=new RechargeDataValidator();			//Object for RechargeDataValidator is obj2
	RechargeFileHelper obj3 = new RechargeFileHelper();				//Object for RechargeFileHelper is obj3
	
	public void displayMenu() throws InvalidNumberException			//Primary Menu displayed to the User
	{
		System.out.println("1.Make a Recharge");
		System.out.println("2.Display Recharge Details");
		System.out.println("3.Exit");
		int option;
		try{
			option=Integer.parseInt(scanner.nextLine());
		}catch(NumberFormatException nfe){
			throw new InvalidNumberException();
			
		}
		switch(option)													//Switch-Case Block to let user choose an option
		{
		case 1:
			recharge();
			displayMenu();
			break;
		case 2:
			details();													//Display Recharge Details
			displayMenu();
			break;
		case 3:
			System.exit(0);												//EXIT
		default:
			throw new InvalidNumberException();
			
		}
	}
	
	public static void main(String[] args) {
		RechargeClient rc = new RechargeClient();					//Object for Recharge Client Class is rc
		try {
			rc.displayMenu();
		} catch (InvalidNumberException e) {
			
		
		}
	}
	
	private void details() 
	{
		obj3.readFile();
		
	}
		private void recharge(){
			System.out.println("Select Recharge Type (Prepaid/Postpaid)");
			String type=scanner.nextLine();
			obj.setRechargeType(type);
			System.out.println("Enter Mobile No.");
			String mobileNo=scanner.nextLine();
			obj.setMobileNo(mobileNo);
			System.out.println("Select Current Operator(Airtel/DoCoMo/BSNL/Jio):");
			String currentOperator=scanner.nextLine(); 
			obj.setCurrentOperator(currentOperator);
			System.out.println("Enter Amount(Rs.):");
			double amount=Math.round(Double.parseDouble(scanner.nextLine()) * 100D) / 100D;
			obj.setAmount(amount);
			if(obj2.validateDetails(obj)) 
			{
				System.out.println("Successful Recharge. Transaction ID: "+obj.getTransactionID());
				obj3.fileWrite(obj);
			}
			else
			{
				System.out.println("Failed to recharge.");				//Error message 
			}
	
		}
		
}
