package com.java.cg.contacts.sevice;

import com.java.cg.contacts.bean.ContactDetails;
import com.java.cg.contacts.dao.ClientDao;
import com.java.cg.contacts.exception.ContactIdNotExist;
import com.java.cg.contacts.exception.DuplicateNameException;

public class ContactsHelper {
	static ClientDao dao = new ClientDao();
	public boolean addContactDetails(ContactDetails contactDetails){
		try {
			dao.addToList(contactDetails);
			return true;
		} catch (DuplicateNameException e) {
			return false;
		}
	}
	public void deleteContactDetails(int contactID){
		try {
			dao.removeFromList(contactID);
		} catch (ContactIdNotExist e) {
			// TODO Auto-generated catch block
			
		}
	}
	
	static{
		try {
			dao.addToList(new ContactDetails("Kirti Roy","9234534500",null,"kirtiroy@yahoo.co.in","FAMILY"));
		} catch (DuplicateNameException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			dao.addToList(new ContactDetails("Raj Singh","8288866678","8234343434","Arun16@gmail.com","FRIENDS"));
		} catch (DuplicateNameException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
