package com.java.cg.contacts.dao;

import java.util.ArrayList;

import com.java.cg.contacts.bean.ContactDetails;
import com.java.cg.contacts.exception.*;

public class ClientDao {
	static ArrayList al = new ArrayList();
	
	public void addToList (ContactDetails details)throws DuplicateNameException{
		boolean flag= false;
		ContactDetails cd;
		for(int i=0;i<al.size();i++)
		{
			cd=(ContactDetails) al.get(i);
			if(cd.getcName().equals(details.getcName())){
				flag=true;
				throw new DuplicateNameException();
			}
		}
		if(flag==false)
		{
			
			try {
				al.add(details);
			} catch (Exception e) {
				System.out.println("Failed to add the contact");
			}
			System.out.println("Contact Added");
			System.out.println("Contact ID is: " + details.getContactID() );
		}
	
	}
	
	
	
	public void removeFromList(int contactID) throws ContactIdNotExist{
		boolean flag=false;
		int i;
		ContactDetails cd;
		for(i=0;i<al.size();i++)
		{
			cd=(ContactDetails) al.get(i);
			if(cd.getContactID()==contactID)
			{
				al.remove(cd);
				flag=true;
				System.out.println("Contact deleted successfully");
				break;
			}
		}
		if(!flag)
		{
			throw new ContactIdNotExist();
		}
		
	}
}
