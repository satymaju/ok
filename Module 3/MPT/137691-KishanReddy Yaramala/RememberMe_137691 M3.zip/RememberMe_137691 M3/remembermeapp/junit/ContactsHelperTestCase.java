package com.java.cg.contacts.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.java.cg.contacts.bean.ContactDetails;
import com.java.cg.contacts.service.ContactsHelper;

public class ContactsHelperTestCase {
	ContactsHelper ch = new ContactsHelper();
	@Test(timeout=10)
	public void testAddContactDetails() {
		assertEquals(true,ch.addContactDetails(new ContactDetails("Raj Singh","8288866678","8234343434","Arun16@gmail.com","FRIENDS")));
	}

}
