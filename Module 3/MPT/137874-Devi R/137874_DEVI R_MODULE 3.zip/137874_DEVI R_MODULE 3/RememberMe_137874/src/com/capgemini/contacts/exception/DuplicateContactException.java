package com.capgemini.contacts.exception;

public class DuplicateContactException extends Exception {
	public DuplicateContactException(){
		System.out.println("Failed to add the Contact");

}
}
