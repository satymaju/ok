package com.capgemini.paymobbill.bean;

import java.io.Serializable;

public class RechargeDetails implements Serializable{
	String rechargeType;
	String currentOperator;
	String mobileNo;
	double amount;
	int transactionID;

	// parameterized constructor with String rechargeType, String currentOperator, String mobileNo, double amount,
	//int transactionID 
	public RechargeDetails(String rechargeType, String currentOperator, String mobileNo, double amount, int transactionID) {
		super();
		this.rechargeType = rechargeType;
		this.currentOperator = currentOperator;
		this.mobileNo = mobileNo;
		this.amount = amount;
		this.transactionID = transactionID;
	}
	
	// getter method of  rechargeType
	public String getRechargeType() {
		return rechargeType;
	}
	
	// setter method of  rechargeType
	public void setRechargeType(String rechargeType) {
		this.rechargeType = rechargeType;
	}
	
	// getter method of  currentOperator
	public String getCurrentOperator() {
		return currentOperator;
	}
	
	// setter method of  currentOperator
	public void setCurrentOperator(String currentOperator) {
		this.currentOperator = currentOperator;
	}
	
	// getter method of mobileNo
	public String getMobileNo() {
		return mobileNo;
	}
	
	// setter method of  mobileNo
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	// getter method of amount
	public double getAmount() {
		return amount;
	}
	
	// setter method of  amount
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	// getter method of  transactionID
	public int getTransactionID() {
		return transactionID;
	}
	
	// transactionID is generated using Math.random function then it is converted into integer value
	public RechargeDetails() {
		this.transactionID = ((int)(Math.random()*9000)+1000);
	}
	
	
	@Override
	public String toString() {
		return "RechargeDetails\n------------------- \nrechargeType: " + rechargeType + "\ncurrentOperator: " + currentOperator + "\nmobileNo: "+ mobileNo + "\namount: " + amount + "\ntransactionID: " + transactionID+"\n--------------------";
	}
	
}
