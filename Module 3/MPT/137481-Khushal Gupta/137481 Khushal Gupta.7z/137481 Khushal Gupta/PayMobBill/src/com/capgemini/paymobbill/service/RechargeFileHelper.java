package com.capgemini.paymobbill.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeFileHelper
{
	//addRechargeDetails(RechargeDetails obj) method is used to write the data in mobile.txt file kept at resources folder
	public void addRechargeDetails(RechargeDetails obj) {
		try 
		{
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("resources/mobile_data.txt"));
			oos.writeObject(obj);
			oos.close();
		}
		catch (FileNotFoundException e)
		{
			System.out.println(e.getMessage());
		}
		catch (IOException e)
		{
			System.out.println(e.getMessage());
		}
	}
	//displayRechargeDetails() method is used to fetch the data from the mobile.txt file kept at resources folder
	public void displayRechargeDetails() {
		try
		{
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream("resources/mobile_data.txt"));
			try
			{
				System.out.println(ois.readObject());
				ois.close();
			}
			catch (ClassNotFoundException e)
			{
				System.out.println(e.getMessage());			
			}
		}
		catch (FileNotFoundException e)
		{
			System.out.println(e.getMessage());
		}
		catch (IOException e) 
		{
			System.out.println(e.getMessage());
		}	
	}
}
