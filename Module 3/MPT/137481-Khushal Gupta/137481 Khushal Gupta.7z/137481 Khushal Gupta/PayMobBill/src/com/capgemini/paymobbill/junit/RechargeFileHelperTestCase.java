package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class RechargeFileHelperTestCase {
	
	RechargeFileHelper rechargefilehelper = new RechargeFileHelper();
	
	RechargeDetails tdata1= new RechargeDetails("prepaid","airtel","8952883292",399,9850);

	@Test(timeout=100)
	public void testFileWrite() {
		rechargefilehelper.addRechargeDetails(tdata1);
		
	}

	@Test(timeout=200)
	public void testReadFile() {
		rechargefilehelper.displayRechargeDetails();
	}

}
