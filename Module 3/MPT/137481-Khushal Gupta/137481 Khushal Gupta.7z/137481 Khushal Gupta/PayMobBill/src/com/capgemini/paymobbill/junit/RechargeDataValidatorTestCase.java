package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeDataValidator;

public class RechargeDataValidatorTestCase
{
	
	RechargeDataValidator rechargedatavalidator = new RechargeDataValidator();
	
	//correct test data entered
	RechargeDetails data1= new RechargeDetails("prepaid","jio","8952883292",399,3562);
	
	//amount entered is not in between 2 to 4 digit(wrong data entered)
	RechargeDetails data2= new RechargeDetails("postpaid","airtel","9876543210",54321,9875);
	
	//transaction id generated is of 5 digit which should be of 4 digit
	RechargeDetails data3= new RechargeDetails("postpaid","bsnl","9123456780",550,98765);
	
	//recharge type entered is wrong
	RechargeDetails data4= new RechargeDetails("sdchasj","jio","8952883292",87,9234);
	
	//current operator entered is wrong. it should be (jio, airtel, bsnl, docomo)
	RechargeDetails data5= new RechargeDetails("prepaid","idea","9873216540",187,2394);
	
	//method to check the all details entered in test data is correct or not
	@Test
	public void testValidateDetails()
	{
		assertEquals(true,rechargedatavalidator.validate_Details(data1));
	}
	
	//method to check the all details entered in test data is correct or not
	@Test
	public void testValidateDetails2()
	{
		assertEquals(true,rechargedatavalidator.validate_Details(data2));
	}
	
	//method to check the all details entered in test data is correct or not
	@Test
	public void testValidateDetails3() 
	{
		assertEquals(true,rechargedatavalidator.validate_Details(data3));
	}
	
	//method to check the all details entered in test data is correct or not
	@Test
	public void testValidateDetails4() 
	{
		assertEquals(false,rechargedatavalidator.validate_Details(data4));
	}
	
	//method to check the all details entered in test data is correct or not
	@Test
	public void testValidateDetails5() 
	{
		assertEquals(false,rechargedatavalidator.validate_Details(data5));
	}

	//method used to check the recharge type entered is correct or not
	@Test
	public void testValidateRechargeType()
	{
		assertEquals(true,rechargedatavalidator.validateRechargeType(data1));
	}
	
	//method used to check the recharge type entered is correct or not
	@Test
	public void testValidateRechargeType2() 
	{
		assertEquals(false,rechargedatavalidator.validateRechargeType(data4));
	}
}
