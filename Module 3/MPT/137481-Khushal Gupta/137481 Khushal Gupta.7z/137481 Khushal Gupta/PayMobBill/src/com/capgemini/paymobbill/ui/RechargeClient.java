package com.capgemini.paymobbill.ui;

import java.security.Provider.Service;
import java.util.Scanner;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.exception.InvalidNumberException;
import com.capgemini.paymobbill.service.RechargeDataValidator;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class RechargeClient {
	
	Scanner sc = new Scanner(System.in);
	RechargeDataValidator rechargedatavalidator=new RechargeDataValidator();
	RechargeFileHelper rechargefilehelper = new RechargeFileHelper();
	RechargeDetails rechargedetail=new RechargeDetails();
	
	// displayMenu method is used to display the options to the consumer
	//1. Make a recharge
	//2.Display Recharge Details
	//3. Exit
	public void displayMenu() throws InvalidNumberException
	{
		int option;
		System.out.println("1.Make a Recharge\n2.Display Recharge Details\n3.Exit");
		try
		{
			option=Integer.parseInt(sc.nextLine());
		}
		catch(NumberFormatException nfe)
		{
			throw new InvalidNumberException();
		}
		switch(option)
		{
		case 1:
			recharge();
			displayMenu();
			break;
		case 2:
			details();
			displayMenu();
			break;
		case 3:
			System.exit(0);
		default:
			throw new InvalidNumberException();
			
		}
	}
	
	//details() method is used to display the details
	private void details() 
	{
		rechargefilehelper.displayRechargeDetails();
		
	}
	
	//recharge() method is used to take input from the user
	private void recharge() 
	{
			//taking input(Recharge type, mobile number, current operator, amount) from user 
			System.out.println("Select Recharge Type (Prepaid/Postpaid): ");
			String type=sc.nextLine();
			rechargedetail.setRechargeType(type);

			System.out.println("Enter Mobile No.: ");
			String mobileNo=sc.nextLine();
			rechargedetail.setMobileNo(mobileNo);

			System.out.println("Select Current Operator (Airtel/Docomo/BSNL/Jio): ");
			String currentOperator=sc.nextLine();
			rechargedetail.setCurrentOperator(currentOperator);

			System.out.println("Enter Amount (Rs.): ");
			double amount=Math.round(Double.parseDouble(sc.nextLine()) * 100D) / 100D;
			rechargedetail.setAmount(amount);
			
			//check the data entered by user is correct or not according to the requirement by using validation.
			if(rechargedatavalidator.validate_Details(rechargedetail)) 
			{
				System.out.println("Successful Recharge. Transaction ID: "+rechargedetail.getTransactionID());
				rechargefilehelper.addRechargeDetails(rechargedetail);
			}
			else
			{
				System.out.println("Failed to Recharge.");
			}
	}
	
	public static void main(String[] args)
	{
		RechargeClient rechargeclient = new RechargeClient();
		try
		{
			rechargeclient.displayMenu();
		}
		catch (InvalidNumberException e)
		{
		}
	}

}
