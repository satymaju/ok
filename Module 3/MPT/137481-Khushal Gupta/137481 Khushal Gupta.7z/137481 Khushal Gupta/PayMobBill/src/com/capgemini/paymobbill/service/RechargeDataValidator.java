package com.capgemini.paymobbill.service;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeDataValidator
{
	//validateRechargeType(RechargeDetails recharge_detail) method is used to check that user has entered prepaid or postpaid.
	public boolean validateRechargeType(RechargeDetails recharge_detail)
	{
		if(recharge_detail.getRechargeType().toLowerCase().equals("prepaid") || recharge_detail.getRechargeType().toLowerCase().equals("postpaid"))
			return true;
		else 
			return false;
	}
	// validateCurrentOperator(RechargeDetails recharge_detail) method is used to check the current operator in
	//airtel, bsnl, docomo, jio
	private boolean validateCurrentOperator(RechargeDetails recharge_detail)
	{
		String x = recharge_detail.getCurrentOperator().toLowerCase();
		if(x.equals("airtel") ||  x.equals("bsnl") || x.equals("docomo")|| x.equals("jio"))
			return true;
		else
			return false;
	}
	//validateMobileNo(RechargeDetails recharge_detail) method is used to check that mobile number should be of 10 digit
	//Its 1st digit can be (7/8/9) and remaining 9 digits can be (0-9)
	private boolean validateMobileNo(RechargeDetails recharge_detail) 
	{
		String MobileNo=recharge_detail.getMobileNo();
		if(MobileNo.matches("[7-9][0-9]{9}"))
			return true;
		else
			return false;
	}
	//validateAmount(RechargeDetails recharge_detail) method is used to check the amount is between 10 to 9999
	private boolean validateAmount(RechargeDetails recharge_detail)
	{
		double amount=recharge_detail.getAmount();
		try
		{
			if(amount>9 && amount<100000)
			return true;
			else
				return false;
		}
		catch(NumberFormatException nfe)
		{
			System.out.println("Please Enter currect amount");
			return false;
		}
	}
	
	//validateDetails(RechargeDetails recharge_detail) method used to call all methods of this class in this method
	//and check that all are returning true or false
	public boolean validate_Details(RechargeDetails recharge_detail)
	{
		if(validateRechargeType(recharge_detail) && validateCurrentOperator(recharge_detail) && validateMobileNo(recharge_detail) && validateAmount(recharge_detail))
			return true;
		else
			return false;
	}
}
