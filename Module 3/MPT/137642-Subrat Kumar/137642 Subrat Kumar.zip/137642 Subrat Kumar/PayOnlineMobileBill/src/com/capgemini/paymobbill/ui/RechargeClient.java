/**
 * 
 */
package com.capgemini.paymobbill.ui;

import java.io.ObjectInputStream;
import java.util.Scanner;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.exception.InvalidDataException;
import com.capgemini.paymobbill.service.RechargeDataValidator;
import com.capgemini.paymobbill.service.RechargeFileHelper;

/**
 * @author subkumar
 *
 */
public class RechargeClient {

	double amount;
	int select;
	Scanner scan = new Scanner(System.in);
	RechargeDataValidator rDataValidator = new RechargeDataValidator();
	RechargeFileHelper rFileHelper = new RechargeFileHelper();
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		RechargeClient rClient = new RechargeClient();
		rClient.uiMenu();

	}
	
	/*
	 *Dipslaying User Interface to the user.
	 */
	private void uiMenu() {
		
		System.out.println("Welcome to Mobile Recharge Portal");
		System.out.println("Select the option to perform action");
		System.out.println("1. Make a Recharge.");
		System.out.println("2. Display Recharge Details.");
		System.out.println("3. Exit.");
		
		try {
			select = Integer.parseInt(scan.nextLine());
		}catch(NumberFormatException nfe) {
			System.out.println("Invalid Number Format");
			uiMenu();
		}
			
			
			switch (select) {
			case 1:
				rechargeMobile();
				uiMenu();
				break;
			
			case 2:
				rechargeDetails();
				uiMenu();
				
			case 3:
				System.out.println("Exiting the Portal...");
				System.exit(0);
			default:
				System.out.println("Inavlid Selection..Choose the Correct given option");
				uiMenu();
				break;
			}
		
	}
	
	/*
	 * Displaying Recharge Details.
	 */
	private void rechargeDetails() {
		
		rFileHelper.displayRechargeDetails();
	}

	 /*
	  * Getting Details from the Client to recharge his/her mobile.
	  */
	private void rechargeMobile() {
		RechargeDetails rDetails = new RechargeDetails();
		System.out.println("Select Recharge Type (Prepaid/Postpaid)");
		rDetails.setRechargeType(scan.nextLine());
		System.out.println("Enter Mobile No.");
		rDetails.setMobileNo(scan.nextLine());
		System.out.println("Select Current Operator (Airtel/DoCoMo/BSNL/Jio)");
		rDetails.setCurrentOperator(scan.nextLine());
		System.out.println("Enter Amount(Rs.)");
		try {
			amount=Math.round(Double.parseDouble(scan.nextLine()) * 100D) / 100D;
		}catch(NumberFormatException nfe) {
			System.out.println("Invalid Amount. Amount should only be in digits in the range of 10-1000");
			
		}
		rDetails.setAmount(amount);
		
		if(rDataValidator.validateRechargeType(rDetails.getRechargeType()) && rDataValidator.validateMobileNo(rDetails.getMobileNo()) && rDataValidator.validateCurrentOperator(rDetails.getCurrentOperator()) && rDataValidator.validateAmount(rDetails.getAmount())) {
			System.out.println("Successful Recharge. transaction ID :" +rDetails.getTransactionID());
			rFileHelper.addRechargeDetails(rDetails);
		}else {
			System.out.println("Failed to Recharge");
		}
	}

}
