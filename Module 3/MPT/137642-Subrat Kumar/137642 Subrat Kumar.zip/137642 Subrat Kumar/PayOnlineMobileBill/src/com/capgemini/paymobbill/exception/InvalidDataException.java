/**
 * 
 */
package com.capgemini.paymobbill.exception;

/**
 * @author subkumar
 *
 */
public class InvalidDataException extends Exception{

}
