/**
 * 
 */
package com.capgemini.paymobbill.service;

import com.capgemini.paymobbill.exception.InvalidDataException;

/**
 * @author subkumar
 *
 */
public class RechargeDataValidator {
	/*
	 * Validating the Recharge Type.
	 */
	public boolean validateRechargeType(String rechargeType) {
		if(rechargeType.toLowerCase().equals("prepaid") || rechargeType.toLowerCase().equals("postpaid")) {
			return true;
		}else {
			try {
				throw new InvalidDataException();
			}catch(InvalidDataException ide) {
				System.out.println("Invalid Recharge Type");
				return false;
			}
		}
	}
	/*
	 * Validating the Current Operator.
	 */
	public boolean validateCurrentOperator(String currentOperator) {
		if(currentOperator.toLowerCase().equals("airtel") || currentOperator.toLowerCase().equals("docomo") || currentOperator.toLowerCase().equals("bsnl") || currentOperator.toLowerCase().equals("jio")) {
			return true;
		}else{
			try {
				throw new InvalidDataException();
			}catch(InvalidDataException ide) {
				System.out.println("Invalid Current Operator");
				return false;
			}
		}
	}
	/*
	 * Validating the Mobile Number.
	 */
	public boolean validateMobileNo(String mobileNo) {
		if(mobileNo.matches("[7-9][0-9]{9}")) {
			return true;
		}else {
			try {
				throw new InvalidDataException();
			}catch(InvalidDataException ide) {
				System.out.println("Invalid Mobile Number. no. should start with 7/8/9 and it should be of 10 digits");
				return false;
			}
		}
	}
	/*
	 * Validating the Amount.
	 */
	public boolean validateAmount(double amount) {
		String dAmount = Double.toString(amount);

		if(amount>=10 && amount<=1000) return true;
		else {
			try {
				throw new InvalidDataException();
			}catch(InvalidDataException ide) {
				System.out.println("Invalid Amount. Amount should only be in digits in the range of 10-1000");
				return false;
			}
		}
	}
}
