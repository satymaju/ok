/**
 * 
 */
package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeFileHelper;

/**
 * @author subkumar
 *
 */
public class RechargeFileHelperTest {
	RechargeDetails rDetails = new RechargeDetails("prepaid","9738075712","vodafone",123);
	RechargeFileHelper rFileHelper = new RechargeFileHelper();

	/**
	 * Test method for {@link com.capgemini.paymobbill.service.RechargeFileHelper#addRechargeDetails(com.capgemini.paymobbill.bean.RechargeDetails)}.
	 */
	@Test
	public void testAddRechargeDetails() {
		assertEquals(true, rFileHelper.addRechargeDetails(rDetails));//It must pass the test.
	}

	/**
	 * Test method for {@link com.capgemini.paymobbill.service.RechargeFileHelper#displayRechargeDetails()}.
	 */
	@Test
	public void testDisplayRechargeDetails() {
		assertEquals(true, rFileHelper.displayRechargeDetails()); //It must pass the test
	}

}
