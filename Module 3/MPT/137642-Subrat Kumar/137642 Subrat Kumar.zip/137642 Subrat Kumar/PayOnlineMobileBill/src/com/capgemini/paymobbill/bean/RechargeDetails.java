/**
 * 
 */
package com.capgemini.paymobbill.bean;

import java.io.Serializable;

/**
 * @author subkumar
 *
 */
public class RechargeDetails implements Serializable {

	String rechargeType;
	String currentOperator;
	String MobileNo;
	double amount;
	int transactionID;
	
	
	/*
	 * Parameterized Constructor which has been used for JUnit Test Cases
	 */
	/**
	 * @param rechargeType
	 * @param currentOperator
	 * @param mobileNo
	 * @param amount
	 */
	public RechargeDetails(String rechargeType,  String mobileNo, String currentOperator, double amount) {
		super();
		this.rechargeType = rechargeType;
		this.currentOperator = currentOperator;
		MobileNo = mobileNo;
		this.amount = amount;
		
	}
	
	/*
	 * Default Constructor
	 */
	public RechargeDetails() {
		transactionID = (int)(Math.random()*9000)+1000 ;
	}
	
	/*
	  * Getters and Setters for the fields.
	  */
	/**
	 * @return the rechargeType
	 */
	public String getRechargeType() {
		return rechargeType;
	}

	/**
	 * @return the currentOperator
	 */
	public String getCurrentOperator() {
		return currentOperator;
	}

	/**
	 * @return the mobileNo
	 */
	public String getMobileNo() {
		return MobileNo;
	}

	/**
	 * @return the amount
	 */
	public double getAmount() {
		return amount;
	}

	/**
	 * @return the transactionID
	 */
	public int getTransactionID() {
		return transactionID;
	}

	/**
	 * @param rechargeType the rechargeType to set
	 */
	public void setRechargeType(String rechargeType) {
		this.rechargeType = rechargeType;
	}

	/**
	 * @param currentOperator the currentOperator to set
	 */
	public void setCurrentOperator(String currentOperator) {
		this.currentOperator = currentOperator;
	}

	/**
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(String mobileNo) {
		MobileNo = mobileNo;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(double amount) {
		this.amount = amount;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "*****Transaction Details***** \nRecharge Type = " + rechargeType + "\nCurrent Operator = " + currentOperator + "\nMobile No. = "
				+ MobileNo + "\nAmount = " + amount + "\nTransactionID = " + transactionID ;
	}	
	
	
}
