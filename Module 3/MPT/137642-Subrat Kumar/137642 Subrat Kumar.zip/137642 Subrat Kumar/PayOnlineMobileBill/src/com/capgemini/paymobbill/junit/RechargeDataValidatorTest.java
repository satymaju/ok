/**
 * 
 */
package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.exception.InvalidDataException;
import com.capgemini.paymobbill.service.RechargeDataValidator;

/**
 * @author subkumar
 *
 */
public class RechargeDataValidatorTest {

	RechargeDetails rDetails = new RechargeDetails("prepaid","9738075712","vodafone",123);
	RechargeDataValidator rDataValidator = new RechargeDataValidator();

	/**
	 * Test method for {@link com.capgemini.paymobbill.service.RechargeDataValidator#validateRechargeType(java.lang.String)}.
	 */
	@Test
	public void testValidateRechargeType() {
		assertEquals(true, rDataValidator.validateRechargeType(rDetails.getRechargeType())); //This test should pass
	}

	/**
	 * Test method for {@link com.capgemini.paymobbill.service.RechargeDataValidator#validateCurrentOperator(java.lang.String)}.
	 */
	@Test
	public void testValidateCurrentOperator() {
		assertEquals(true, rDataValidator.validateCurrentOperator(rDetails.getCurrentOperator())); //This test should fail
	}

	/**
	 * Test method for {@link com.capgemini.paymobbill.service.RechargeDataValidator#validateMobileNo(java.lang.String)}.
	 */
	@Test
	public void testValidateMobileNo() {
		assertEquals(true, rDataValidator.validateMobileNo(rDetails.getMobileNo())); //This test should pass
	}

	/**
	 * Test method for {@link com.capgemini.paymobbill.service.RechargeDataValidator#validateAmount(double)}.
	 */
	@Test
	public void testValidateAmount() {
		assertEquals(true, rDataValidator.validateAmount(rDetails.getAmount())); //This test should pass
	}
}
