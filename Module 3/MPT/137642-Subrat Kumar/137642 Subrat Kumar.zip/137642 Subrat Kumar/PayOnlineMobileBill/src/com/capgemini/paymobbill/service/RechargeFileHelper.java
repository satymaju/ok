/**
 * 
 */
package com.capgemini.paymobbill.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.capgemini.paymobbill.bean.RechargeDetails;

/**
 * @author subkumar
 *
 */
public class RechargeFileHelper {
	
	/*
	 * Writing object to the File
	 */
	public boolean addRechargeDetails(RechargeDetails rechargeDetails) {
		ObjectOutputStream oos;
		try {
			oos = new ObjectOutputStream(new FileOutputStream("data/MobileBill.obj",true));
			oos.writeObject(rechargeDetails);
			oos.close();
			return true;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			
			e.printStackTrace();
			return false;
		}
		
	}
	/*
	 * Reading Objects from the file.
	 */
	public boolean displayRechargeDetails() {
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream("data/MobileBill.obj"));
			try {
				
				System.out.println(ois.readObject());				
				return true;
				
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
				return false;
			}
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			
			e.printStackTrace();
			return false;
		}
		
		
	}
	
}
