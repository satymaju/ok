package com.capgemini.paymobbill.exception;

//*********************************EXCEPTION***************************************//

public class InvalidNumberException extends Exception {
	public InvalidNumberException() {
		System.out.println("You have entered an Invalid Number");

	}
}
