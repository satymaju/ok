package com.capgemini.paymobbill.service;

import com.capgemini.paymobbill.bean.RechargeDetails;

//*********************************RECHARGE DATA VALIDATION CLASS*******************************//
public class RechargeDataValidator {

//*** VARIOUS VALIDATIONS ***//
	
	public boolean validateDetails(RechargeDetails pru)
	{
		if(validateRechargeType(pru) && validateMobileNo(pru) && validateCurrentOperator(pru) && validateAmount(pru) && validateTransactionID(pru))
		{
			return true;
		}
		else{
			return false;
		}
	}
	
//*** Function to generate Transaction_ID of 4-digit ***//
	
	private boolean validateTransactionID(RechargeDetails pru) 
	{
		String transactionID= Integer.toString(pru.getTransactionID());
		if(transactionID.matches("[0-9]{4}")) {
			return true;
		}else {
			return false;
		}
	}

//*** Amount can be minimum 2-digit and max 4-digit number ***//
	
	private boolean validateAmount(RechargeDetails pru)
	{
		double amount=pru.getAmount();
		try {
			if(amount>=10 && amount<=9999)
			{
				return true;
			}
			else
			{
				return false;
			}
		}catch(NumberFormatException nfe) {
			System.out.println("Please Enter Correct Amount !!");
			return false;
		}
	}//*** Try Catch Method ***//
	
//*** Current Operator can be Airtel/DoCoMo/BSNL/Jio ***//
	
	private boolean validateCurrentOperator(RechargeDetails pru)
	{
		String x = pru.getCurrentOperator().toLowerCase();
		String y = pru.getCurrentOperator().toLowerCase();
		String z = pru.getCurrentOperator().toLowerCase();
		String a = pru.getCurrentOperator().toLowerCase();
		if(x.equals("Airtel") ||  y.equals("BSNL") || z.equals("DoCoMo")|| a.equals("Jio"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

//*** Mobile No. should contain only a 10-digit number and the 10 digit number should start with either 7/8/9 ***//
	
	private boolean validateMobileNo(RechargeDetails pru) 
	{
		String MobileNo=pru.getMobileNo();
		if(MobileNo.matches("[7-9][0-9]{9}"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

//*** Recharge type can either be Prepaid or Postpaid ***//
	
	public boolean validateRechargeType(RechargeDetails pru)
	{
		if(pru.getRechargeType().toLowerCase().equals("Prepaid") || pru.getRechargeType().toLowerCase().equals("Postpaid"))
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
}
