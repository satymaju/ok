package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeFileHelper;

//*********************************RECHARGE FILE HELPER CASE******************************//

	public class RechargeFileHelperTestCase {
	
		RechargeFileHelper rfh = new RechargeFileHelper();
	
		RechargeDetails tdata1= new RechargeDetails("Prepaid","Jio","7073167918",309,1234);
		

//************************************AUTO-TEST*****************************************//
	
	@Test(timeout=50)
	public void testFileWrite() {
		rfh.fileWrite(tdata1);	
	}

	@Test(timeout=200)
	public void testReadFile() {
		rfh.readFile();
	}

}
