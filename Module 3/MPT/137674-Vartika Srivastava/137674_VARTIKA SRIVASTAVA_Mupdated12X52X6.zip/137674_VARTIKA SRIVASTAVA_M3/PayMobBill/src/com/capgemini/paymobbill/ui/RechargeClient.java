package com.capgemini.paymobbill.ui;

import java.security.Provider.Service;
import java.util.Scanner;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.exception.InvalidNumberException;
import com.capgemini.paymobbill.service.RechargeDataValidator;
import com.capgemini.paymobbill.service.RechargeFileHelper;

//******************************** RECHARGE CLIENT CLASS *****************************//

public class RechargeClient {
	Scanner scanner = new Scanner(System.in);
	RechargeDetails obj=new RechargeDetails();
	RechargeDataValidator rdv=new RechargeDataValidator();
	RechargeFileHelper rfh = new RechargeFileHelper();
	public static void main(String[] args) {
		RechargeClient rc = new RechargeClient();
		try {
			rc.displayMenu();
		} catch (InvalidNumberException e) {	// Using Try Catch
	}
}
	
//*************************************** MENU ***************************************//
	
	public void displayMenu() throws InvalidNumberException
	{
		System.out.println(" ********** MENU ********** ");
		System.out.println("Please select from the following:");
		System.out.println("1.  Make a Recharge");
		System.out.println("2.  Display Recharge Details");
		System.out.println("3.  Exit.");
		int option;
		try{
			option=Integer.parseInt(scanner.nextLine());
		}catch(NumberFormatException nfe){
			throw new InvalidNumberException(); // Using Try Catch 
		}
		switch(option)
		{
		case 1:
			recharge();
			displayMenu();
			break;
		case 2:
			System.out.println("Details are:");
			details();
			displayMenu();
			break;
		case 3:
			System.out.println("Quiting the Application !!");
			System.exit(0);
		default:
			throw new InvalidNumberException();
			
		}// Using Switch creating Case1 for Recharge Case2 for Display and Case3 for Quiting
		
	}
	private void details() 
	{
		rfh.readFile();
		
	}
// If the Customer selects option1 following will be the next details asked.
	private void recharge() 
	{
			
			System.out.println("Select Recharge Type (Prepaid/Postpaid) :");
			String type=scanner.nextLine();
			obj.setRechargeType(type);
			
			System.out.println("Enter Mobile No.:");
			String mobileNo=scanner.nextLine();
			obj.setMobileNo(mobileNo);
			
			System.out.println("Select Current Operator (Airtel/DoCoMo/BSNL/Jio) :");
			String currentOperator=scanner.nextLine();
			obj.setCurrentOperator(currentOperator);
			
			System.out.println("Enter Amount (Rs.):");
			double amount=Math.round(Double.parseDouble(scanner.nextLine()) * 100D) / 100D;
			obj.setAmount(amount);
			
//************** If the Above Details are correctly Entered			
			if(rdv.validateDetails(obj)) 
			{
				System.out.println("Successful Recharge. Transaction ID: "+obj.getTransactionID());
				rfh.fileWrite(obj);
			}
//************** If the Above Details are not correctly Entered
			else
			{
				System.out.println("Failed to Recharge.");
			}	
	}
		
}
