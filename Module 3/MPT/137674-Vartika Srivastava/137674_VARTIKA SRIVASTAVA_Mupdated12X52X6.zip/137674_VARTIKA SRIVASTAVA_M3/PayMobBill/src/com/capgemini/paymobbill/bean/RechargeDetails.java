package com.capgemini.paymobbill.bean;

import java.io.Serializable;

//******************************INITIALIZATION*********************************//
//****************************** RECHARGE DETAILS CLASS ***********************//
	public class RechargeDetails implements Serializable{
		public String rechargeType;
		public String currentOperator;
		public String mobileNo;
		public double amount;
		public int transactionID;
	
//******************************GETTERS AND SETTERS***************************//
		
	public RechargeDetails() {
		this.transactionID = (int)(Math.random()*3000)+500;
	}
	public String getRechargeType() {
		return rechargeType;
	}
	public void setRechargeType(String rechargeType) {
		this.rechargeType = rechargeType;
	}
	public String getCurrentOperator() {
		return currentOperator;
	}
	public void setCurrentOperator(String currentOperator) {
		this.currentOperator = currentOperator;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getTransactionID() {
		return transactionID;
	}
	
//*********************************CALLING FUNCTION*****************************************//
	
	public RechargeDetails(String rechargeType, String currentOperator, String mobileNo, double amount, int transactionID) {
		super();
		this.rechargeType = rechargeType;
		this.currentOperator = currentOperator;
		this.mobileNo = mobileNo;
		this.amount = amount;
		this.transactionID = transactionID;
	}
	
//*********************************AUTO-OVERRIDE******************************************//
	
	@Override
	public String toString() {
		return "RechargeDetails [rechargeType=" + rechargeType + ", currentOperator=" + currentOperator + ", mobileNo="
				+ mobileNo + ", amount=" + amount + ", transactionID=" + transactionID + "]";
	}
	
}
