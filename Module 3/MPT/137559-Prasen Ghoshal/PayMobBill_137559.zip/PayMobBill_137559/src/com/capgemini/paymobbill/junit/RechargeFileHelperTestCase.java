package com.capgemini.paymobbill.junit;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class RechargeFileHelperTestCase {
	
	RechargeFileHelper rfh = new RechargeFileHelper();
	
	RechargeDetails test1= new RechargeDetails("prepaid","jio","9874123456",309,1924);

	@Test(timeout=50)
	public void testFileWrite() {
		rfh.fileWrite(test1);
		
	}

	@Test(timeout=200)
	public void testReadFile() {
		rfh.fileRead();
	}

}
