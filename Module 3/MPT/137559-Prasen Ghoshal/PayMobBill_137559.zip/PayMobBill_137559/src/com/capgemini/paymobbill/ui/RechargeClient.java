package com.capgemini.paymobbill.ui;

import java.util.Scanner;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.exception.InvalidInputException;
import com.capgemini.paymobbill.service.RechargeDataValidator;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class RechargeClient {
	Scanner sc=new Scanner(System.in);
	RechargeDetails rd=new RechargeDetails();
	RechargeDataValidator rdv=new RechargeDataValidator();
	RechargeFileHelper rfh=new RechargeFileHelper();
	String filePath="MobileBill.obj";
	public void displayMenu(){
		System.out.println("1. Make a Recharge");
		System.out.println("2. Display Recharge Details");
		System.out.println("3. Exit");
		int option=Integer.parseInt(sc.nextLine());
		switch(option){
		case 1:
			makeRecharge();
			displayMenu();
			break;
		case 2:
			displayRecharge();
			displayMenu();
			break;
		case 3:
			System.exit(0);
			break;
		default:
			System.out.println("Please select a valid option");
			displayMenu();
		}
	}
	public void makeRecharge(){
		try{
			System.out.println("Select Recharge Type (Prepaid/Postpaid) : ");
			rd.setRechargeType(sc.nextLine());
			if(!rdv.validateRechargeType(rd))
				throw new InvalidInputException();
				
			System.out.println("Enter Mobile No.: ");
			rd.setMobileNo(sc.nextLine());
			if(!rdv.validateMobileNo(rd))
				throw new InvalidInputException();
			
			System.out.println("Select Current Operator (Airtel/DoCoMo/BSNL/Jio) : ");
			rd.setCurrentOperator(sc.nextLine());
			if(!rdv.validateCurrentOperator(rd))
				throw new InvalidInputException();
			
			System.out.println("Enter Amount (Rs.): ");
			double amt=Math.round(Double.parseDouble(sc.nextLine()));
			rd.setAmount(amt);
			if(!rdv.validateAmount(rd))
				throw new InvalidInputException();
			System.out.println("Successful Recharge. Transaction ID: "+rd.getTransactionID());
			rfh.fileWrite(rd);
			
		}catch(NumberFormatException nfe){
			System.out.println(nfe.getMessage());
		}
		catch(InvalidInputException iie)  
		{  //handling user defined exception
			System.out.println(iie.getMessage());
		}
	}
	public void displayRecharge(){
		rfh.fileRead();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RechargeClient rc=new RechargeClient();
		rc.displayMenu();

	}

}
