package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeDataValidator;

public class RechargeDataValidatorTestCase {

	RechargeDataValidator rdv = new RechargeDataValidator();
	RechargeDetails test1= new RechargeDetails("prepaid","docomo","9874123456",309,1234);
	RechargeDetails test2= new RechargeDetails("postpaid","jiooo","9874123456",308,1234);
	RechargeDetails test3= new RechargeDetails("prepaid","airtel","9874123456",3087,19234);
	RechargeDetails test4= new RechargeDetails("prepaid","airtel","98741234569",307,1923);
	RechargeDetails test5= new RechargeDetails("pre","bsnl","9874123456",3087,1923);
	RechargeDetails test6= new RechargeDetails("prepaid","jio","9874123456",3087,1923);
	RechargeDetails test7= new RechargeDetails("postpaid","AIRTEL","9874123456",387,1924);
	RechargeDetails test8= new RechargeDetails("prepaid","bsnl","9874123456",30877,7923);
	RechargeDetails test9= new RechargeDetails("prepaid","Docomo","1874123456",377,7923);
	
	@Test
	public void testValidateDetails1() {
		assertEquals(true,rdv.validateDetails(test1));
	}
	
	@Test
	public void testValidateDetails2() {
		assertEquals(false,rdv.validateCurrentOperator(test2));
	}
	
	@Test
	public void testValidateDetails3() {
		assertEquals(false,rdv.validateTransactionID(test3));
	}
	@Test
	public void testValidateDetails4() {
		assertEquals(false,rdv.validateMobileNo(test4));
	}
	@Test
	public void testValidateRechargeType() {
		assertEquals(false,rdv.validateRechargeType(test5));
	}
	
	@Test
	public void testValidateRechargeType2() {
		assertEquals(true,rdv.validateDetails(test6));
	}
	@Test
	public void testValidateDetails5() {
		assertEquals(true,rdv.validateCurrentOperator(test7));
	}
	@Test
	public void testValidateDetails6() {
		assertEquals(false,rdv.validateAmount(test8));
	}
	public void testValidateDetails7() {
		assertEquals(false,rdv.validateMobileNo(test9));
	}

}
