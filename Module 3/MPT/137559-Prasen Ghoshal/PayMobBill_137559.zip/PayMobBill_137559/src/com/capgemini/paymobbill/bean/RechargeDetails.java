package com.capgemini.paymobbill.bean;

import java.io.Serializable;

public class RechargeDetails implements Serializable{
	String rechargeType;
	String currentOperator;
	String mobileNo;
	double amount;
	int transactionID;
	public RechargeDetails() {
		this.transactionID = (int)(Math.random()*1000)+1000;
	}
	public String getRechargeType() {
		return rechargeType;
	}
	public void setRechargeType(String rechargeType) {
		this.rechargeType = rechargeType;
	}
	public String getCurrentOperator() {
		return currentOperator;
	}
	public void setCurrentOperator(String currentOperator) {
		this.currentOperator = currentOperator;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(int transactionId) {
		this.transactionID = transactionId;
	}
	public RechargeDetails(String rechargeType,String currentOperator,String mobileNo,double amount,int transactionID){
		super();
		this.rechargeType=rechargeType;
		this.currentOperator=currentOperator;
		this.mobileNo=mobileNo;
		this.amount=amount;
		this.transactionID=transactionID;
	}
	@Override
	public String toString() {
		return "RechargeDetails rechargeType= " + rechargeType+ ", currentOperator= " + currentOperator + ", mobileNo= "+ mobileNo + ", amount= " + amount + ", transactionID= "+transactionID;
	}
	
}
