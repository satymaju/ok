package com.capgemini.paymobbill.service;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeDataValidator {
	public boolean validateRechargeType(RechargeDetails rd1){
		if(rd1.getRechargeType().toLowerCase().equals("prepaid") || rd1.getRechargeType().toLowerCase().equals("postpaid")){
			return true;
		}
		else{
			System.out.println("Please enter a valid Recharge Type");
			return false;
		}
	}
	public boolean validateMobileNo(RechargeDetails rd1){
		if(rd1.getMobileNo().matches("[7-9][0-9]{9}"))
		{
			return true;
		}
		else{
			System.out.println("Please enter a valid Mobile No.");
			return false;
		}
	}
	public boolean validateCurrentOperator(RechargeDetails rd1){
		if(rd1.getCurrentOperator().toLowerCase().equals("airtel") || rd1.getCurrentOperator().toLowerCase().equals("docomo") || rd1.getCurrentOperator().toLowerCase().equals("bsnl") || rd1.getCurrentOperator().toLowerCase().equals("jio")){
			return true;
		}
		else{
			System.out.println("Please enter a valid Current Operator");
			return false;
		}
	}
	public boolean validateAmount(RechargeDetails rd1){
		if(rd1.getAmount()>=10 && rd1.getAmount()<=9999){
			return true;
		}
		else{
			System.out.println("Please enter a valid Amount");
			return false;
		}
	}
	public boolean validateTransactionID(RechargeDetails rd1){
		if(rd1.getTransactionID()>=1000 && rd1.getTransactionID()<=9999){
			return true;
		}
		else{
			return false;
		}
	}
	public boolean validateDetails(RechargeDetails rd1){
		if(validateRechargeType(rd1) && validateMobileNo(rd1) && validateCurrentOperator(rd1) && validateAmount(rd1) && validateTransactionID(rd1)){
			return true;
		}
		else{
			return false;
		}
	}

}
