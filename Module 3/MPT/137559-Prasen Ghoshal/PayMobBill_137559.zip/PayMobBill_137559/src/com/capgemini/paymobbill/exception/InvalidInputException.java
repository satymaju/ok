package com.capgemini.paymobbill.exception;

public class InvalidInputException extends Exception{
	public String getMessage()  
	{
		return "Failed to recharge.\n";
	}

}
