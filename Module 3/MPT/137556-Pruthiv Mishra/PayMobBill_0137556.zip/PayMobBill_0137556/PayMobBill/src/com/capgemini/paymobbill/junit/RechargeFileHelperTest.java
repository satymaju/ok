package com.capgemini.paymobbill.junit;


import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeDataValidator;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class RechargeFileHelperTest {
	RechargeFileHelper ob=new RechargeFileHelper();
	RechargeDetails obj = new RechargeDetails("prepaid","airtel","9439344111",1999d,1234);
	RechargeDataValidator rdv= new RechargeDataValidator();
	@Test
	public void testaddRechargeDetails() {
		assertEquals(true,rdv);
	}
	

	
//	@Test
//	void testdisplayRechargeDetails() 
//	{
//	
//	}

}
