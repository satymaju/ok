package com.capgemini.paymobbill.service;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeDataValidator 
{
	//Method to validate all the validators
	//This method checks if allt he fields were correctly filled then it will return true.
	public boolean validateDetails(RechargeDetails pru)
	{
		if(validateRechargeType(pru) && validateMobileNo(pru) && validateCurrentOperator(pru) && validateAmount(pru))
		{
			return true;
			
		}
		else
		{
			return false;
		}
	}
	
	//Method to validate the amount entered by user.
	//This method allows only the amount between 10 to 9999.
	public boolean validateAmount(RechargeDetails pru)
	{
		double amount=pru.getAmount();
		 
			if(amount>=10 && amount<=9999)
			{
				return true;
			}
			else
			{
				System.out.println("Please enter a amount between 10 to 9999 (both inclusive)\n");
				return false;
			}
		
	}
	
	//Method to validate the Current Operator entered by the user.
	//This method allows only to select operators between airtel or bsnl or docomo or jio.
	public boolean validateCurrentOperator(RechargeDetails pru)
	{
		String x = pru.getCurrentOperator().toLowerCase();
		String y = pru.getCurrentOperator().toLowerCase();
		String z = pru.getCurrentOperator().toLowerCase();
		String a = pru.getCurrentOperator().toLowerCase();
		if(x.equals("airtel") ||  y.equals("bsnl") || z.equals("docomo")|| a.equals("jio"))
		{
			return true;
		}
		else
		{
			System.out.println("Choose operator name airtel/docomo/bsnl/jio only.\n");
			return false;
		}
	}
	
	//Method to validate the Mobile Number entered by the user.
	//This method allows only a 10-digit number starting either 7/8/9.
	public boolean validateMobileNo(RechargeDetails pru) 
	{
		String MobileNo=pru.getMobileNo();
		if(MobileNo.matches("[7-9][0-9]{9}"))
		{
			return true;
		}
		else
		{
			System.out.println("Invalid Mobile Number.\n");
			return false;
		}
	}
	
	//Method to validate the Recharge Type entered by the user
	//This method allows the user to select from the type prepaid or postpaid
	public boolean validateRechargeType(RechargeDetails pru)
	{
		if(pru.getRechargeType().toLowerCase().equals("prepaid") || pru.getRechargeType().toLowerCase().equals("postpaid"))
		{
			return true;
		}
		System.out.println("Choose recharge type prepaid or postpaid only.\n");
		return false;
	}
	
	

}

