package com.capgemini.paymobbill.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeDataValidator;

public class RechargeDataValidatorTest {

	@Test
	public void test() {
		RechargeDetails obj = new RechargeDetails("postpaid","airtel","9439344111",10999d,1234);
		RechargeDataValidator rdv = new RechargeDataValidator();
	}
		void testValidateDetails() {
			//assertEquals(rdv,obj);
	}

}
