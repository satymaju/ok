package com.capgemini.paymobbill.ui;

import java.util.Scanner;

import com.capgemini.paymobbill.bean.RechargeDetails;
import com.capgemini.paymobbill.service.RechargeDataValidator;
import com.capgemini.paymobbill.service.RechargeFileHelper;

public class RechargeClient {
	Scanner scanner=new Scanner(System.in);
	RechargeDetails detail=new RechargeDetails();
	RechargeFileHelper file=new RechargeFileHelper();
	public static void main(String[] args) {
		 RechargeClient client=new RechargeClient();
		 client.displayMenu();
	}
	
	public void displayMenu(){
		try{
		do{
		System.out.println("Select any one from the options given below:");
		System.out.println("1.Make a Recharge");
		System.out.println("2.Display Recharge Details");
		System.out.println("3.Exit");
		int option=Integer.parseInt(scanner.nextLine());
		switch(option){
			case 1:
				makeRecharge();
				break;
			case 2:
				displayDetails();
				break;
			case 3:
				System.exit(0);
			default:
				System.out.println("Enter a valid option");
		}
		}while(true);
		}
		catch(NumberFormatException e){
			System.out.println("Enter a valid number");
		}
	}
	
	public void displayDetails() {
		file.displayRechargeDetails();
	}

	public void makeRecharge(){
		
			try{
			detail=getDetails();
			System.out.println("Successful Recharge. Transaction ID : "+detail.getTransactionId());
			}
			catch(NumberFormatException e){
				System.out.println("Failed to Recharge "+ e.getMessage());
			}
			catch(NullPointerException e){
				e.printStackTrace();
			}
			file.addRechargeDetails(detail);
		
	}

	public RechargeDetails getDetails() {
		RechargeDataValidator validate = new RechargeDataValidator();
		boolean value=false;
		do{
		System.out.println("Select Recharge Type(Prepaid / Postpaid) : ");
		detail.setRechargeType((scanner.nextLine()));
		value=validate.validateRechargeType(detail.getRechargeType());
		}while(value==false);
		do{
		System.out.println("Enter Mobile No.:");
		detail.setMobileNo(scanner.nextLine());
		value=validate.validateMobileNo(detail.getMobileNo());
		}while(value==false);
		do{
		System.out.println("Select Current Operator (Airtel / DoCoMo / BSNL / Jio) : ");
		detail.setCurrentOperator((scanner.nextLine().toLowerCase()));
		value=validate.validateCurrentOperator(detail.getCurrentOperator());
		}while(value==false);
		do{
		System.out.println("Enter Amount (Rs.): ");
		detail.setAmount((Double.parseDouble(scanner.nextLine())));
		value=validate.validateAmount(detail.getAmount());
		}while(value==false);
		return detail;
	}
}
