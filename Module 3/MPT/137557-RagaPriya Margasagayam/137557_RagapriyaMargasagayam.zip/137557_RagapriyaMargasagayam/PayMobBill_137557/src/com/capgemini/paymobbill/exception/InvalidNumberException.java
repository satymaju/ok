package com.capgemini.paymobbill.exception;

public class InvalidNumberException extends Exception {
	public InvalidNumberException() {
		
	}
}
