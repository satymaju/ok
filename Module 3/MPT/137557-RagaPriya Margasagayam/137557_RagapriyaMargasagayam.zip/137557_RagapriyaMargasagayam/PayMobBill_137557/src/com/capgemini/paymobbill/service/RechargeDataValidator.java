package com.capgemini.paymobbill.service;

import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeDataValidator {
	RechargeDetails detail=new RechargeDetails();
	public boolean validateRechargeType(String rechargeType){
		switch(rechargeType){
		case "prepaid":
			return true;
		case "postpaid":
			return true;
		default:
			return false;
		}
	}
	public boolean validateCurrentOperator(String currentOperator){
		switch(currentOperator){
		case "airtel":
			return true;
		case "docomo":
			return true;
		case "bsnl":
			return true;
		case "jio":
			return true;
		default:
			return false;
		
		}
	}
	public boolean validateMobileNo(String mobileNo){
		boolean value=mobileNo.matches("([7]|[8]|[9])([0-9]{9})");
		return value;
	}
	public boolean validateAmount(double amount) {
		if(amount>9 && amount<10000){
			return true;
		}
		else{
			return false;
		}
	}
}
