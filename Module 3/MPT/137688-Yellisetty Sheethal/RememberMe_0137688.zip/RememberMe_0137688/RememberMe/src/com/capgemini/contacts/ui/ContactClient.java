package com.capgemini.contacts.ui;

import java.util.Scanner;

import com.capgemini.contacts.bean.ContactDetails;
import com.capgemini.contacts.service.*;

public class ContactClient {
	static Scanner scanner=new Scanner(System.in) ;
	public static void main(String[] args)
	{
		ContactClient C=new ContactClient();
		C.DisplayMenu();
	}
	public void DisplayMenu()
	{
		int selection;
		boolean validate=false;
		ContactsValidator service = new ContactsValidator(); 
		ContactDetails details = new ContactDetails();
		ContactsHelper helper = new ContactsHelper();
		
		while(true)
		{
			System.out.println("Please make your selection :");
			System.out.println("1. Add New Contact");
			System.out.println("2. Delete the Contact");
			System.out.println("3. Exit");
			
			try {
				selection=Integer.parseInt(scanner.nextLine());
			
			
			switch(selection){
			case 1:
				do{
					System.out.println("Enter Details to be stored:");
					details= takeUserInput();
					validate=service.validateDetails(details);
					if(!validate)
					{
						
						System.out.println("Please Enter the correct Details");
					}
				}
				while(validate==false);
				helper.addContactDetails(details);
				
				break;
			case 2:
				System.out.println("Enter the contact ID: ");
				int contactID = Integer.parseInt(scanner.nextLine());
				helper.deleteContactDetails(contactID);
				break;
			case 3:
				System.exit(0);
				
			default: 
				System.out.println("You have entered wrong selection");
			
			}
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				System.out.println("Please enter valid selection");
			}
			}
		}
		
		public static ContactDetails takeUserInput(){
			ContactDetails details = new ContactDetails();
		
			System.out.print("Enter Name : ");
			details.setcName(scanner.nextLine());
			System.out.print("Enter Mobile No. : ");
			details.setMobileNo1(scanner.nextLine());
			System.out.print("Do you want to add alternate Mobile No. ? ");
			
			char ch;
			ch = scanner.nextLine().charAt(0);
			if(ch=='y' || ch=='Y')
			{
				System.out.print("Enter Mobile No. : ");
				details.setMobileNo2(scanner.nextLine());
			}
			else{
				details.setMobileNo2(null);
			}
			System.out.print("Enter Email Id : ");
			details.setEmailID(scanner.nextLine());
			
			System.out.print("Select the Group (Friends/Family/CoWorkers) : ");
			String group=scanner.nextLine().toUpperCase();
			details.setGroupName(group);
			
			return details;
		}
		}
	


