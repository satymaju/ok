package com.capgemini.contacts.service;

import com.capgemini.contacts.Exception.ContactIdNotExist;
import com.capgemini.contacts.Exception.DuplicateNameException;
import com.capgemini.contacts.bean.ContactDetails;
import com.capgemini.contacts.dao.ClientDao;


	public class ContactsHelper {
		static ClientDao dao = new ClientDao();
		public boolean addContactDetails(ContactDetails contactDetails){
			try {
				dao.addToList(contactDetails);
				return true;
			} catch (DuplicateNameException e) {
				return false;
			}
		}
		public void deleteContactDetails(int contactID){
			try {
				dao.removeFromList(contactID);
			} catch (ContactIdNotExist e) {
				// TODO Auto-generated catch block
				
			}
		}
		
		static{
			try {
				dao.addToList(new ContactDetails("Kirti Roy","9234534500",null,"kirtiroy@yahoo.co.in","FAMILY"));
			} catch (DuplicateNameException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				dao.addToList(new ContactDetails("Raj Singh","8288866678","8234343434","Arun16@gmail.com","FRIENDS"));
			} catch (DuplicateNameException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}


