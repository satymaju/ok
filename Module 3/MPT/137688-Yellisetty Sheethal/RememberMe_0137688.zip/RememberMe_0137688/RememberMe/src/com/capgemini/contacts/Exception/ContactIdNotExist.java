package com.capgemini.contacts.Exception;

public class ContactIdNotExist extends Exception {
	public ContactIdNotExist(){
		System.out.println("Contact Id not exist");
	}
}


