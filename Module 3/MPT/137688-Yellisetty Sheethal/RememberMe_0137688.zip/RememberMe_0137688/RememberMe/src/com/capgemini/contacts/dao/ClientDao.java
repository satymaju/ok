package com.capgemini.contacts.dao;

import java.util.ArrayList;

import com.capgemini.contacts.bean.ContactDetails;
import com.capgemini.contacts.Exception.*;

public class ClientDao {
	static ArrayList alist = new ArrayList();
	
	public void addToList (ContactDetails details)throws DuplicateNameException{
		boolean flag= false;
		ContactDetails cd;
		for(int i=0;i<alist.size();i++)
		{
			cd=(ContactDetails) alist.get(i);
			if(cd.getcName().equals(details.getcName())){
				flag=true;
				throw new DuplicateNameException();
			}
		}
		if(flag==false)
		{
			
			try {
				alist.add(details);
			} catch (Exception e) {
				System.out.println("Failed to add the contact");
			}
			System.out.println("Contact Added");
			System.out.println("Contact ID is: " + details.getContactID() );
		}
	
	}
	
	
	
	public void removeFromList(int contactID) throws ContactIdNotExist{
		boolean flag=false;
		int i;
		ContactDetails cd;
		for(i=0;i<alist.size();i++)
		{
			cd=(ContactDetails) alist.get(i);
			if(cd.getContactID()==contactID)
			{
				alist.remove(cd);
				flag=true;
				System.out.println("Contact deleted successfully");
				break;
			}
		}
		if(!flag)
		{
			throw new ContactIdNotExist();
		}
		
	}
}
