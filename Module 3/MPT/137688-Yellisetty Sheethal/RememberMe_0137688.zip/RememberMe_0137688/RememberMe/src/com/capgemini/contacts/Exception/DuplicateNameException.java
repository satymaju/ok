package com.capgemini.contacts.Exception;

public class DuplicateNameException extends Exception {
	public DuplicateNameException(){
		System.out.println("Duplicate Contact found. Failed to add the Contact");
	}
}
