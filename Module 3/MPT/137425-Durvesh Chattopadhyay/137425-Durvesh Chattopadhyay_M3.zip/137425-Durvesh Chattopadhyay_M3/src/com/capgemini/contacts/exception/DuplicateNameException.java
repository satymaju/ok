package com.capgemini.contacts.exception;


//*****Duplicate Contact method**********// 
public class DuplicateNameException extends Exception {
	public DuplicateNameException(){
		System.out.println("Duplicate Contact. Failed to add the Contact");
	}
}
