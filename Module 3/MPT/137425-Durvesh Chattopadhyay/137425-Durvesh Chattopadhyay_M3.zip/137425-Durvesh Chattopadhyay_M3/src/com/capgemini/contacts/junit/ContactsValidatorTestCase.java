package com.capgemini.contacts.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.contacts.service.ContactsValidator;

//**** Method for validation for the following cName, cMobileNo, EmailID and Group name*****// 
public class ContactsValidatorTestCase {
	ContactsValidator cv = new ContactsValidator();
	@Test
	public void testValidateCName() {
		assertEquals(false,cv.validateCName("sho")); //Validation for name//
	}

	@Test
	public void testValidateMobileNo() {
		assertEquals(false,cv.validateMobileNo("123456")); //Validation for mobile no//
	}

	@Test
	public void testValidateEmailID() {
		assertEquals(false,cv.validateEmailID("sfhdskfhs"));  //Validation for EmailID//
	}

	@Test
	public void testValidateGroupName() {
		assertEquals(false,cv.validateGroupName("ghdfgdfgdg"));  //Validation for GroupName//
	}

}
