package com.capgemini.contacts.exception;


//*******Method for If ContactID does not exist**********//
public class ContactIdNotExist extends Exception {
	public ContactIdNotExist(){
		System.out.println("Contact Id not exist");
	}
}
