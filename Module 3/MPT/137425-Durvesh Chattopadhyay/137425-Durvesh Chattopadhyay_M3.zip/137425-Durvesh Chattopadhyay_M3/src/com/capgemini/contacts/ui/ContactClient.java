package com.capgemini.contacts.ui;

import java.util.Scanner;

import com.capgemini.contacts.bean.ContactDetails;
import com.capgemini.contacts.service.ContactsHelper;
import com.capgemini.contacts.service.ContactsValidator;

/*Author name: Durvesh R Chattopadhyay 
 * 
 Designation : Analyst
 
 EmpId: 137425
 
 Created and modified on : 6/11/2017

This class contains the main method which is displaying the inputs and data entered by the user. */ 

public class ContactClient {
	static Scanner scan = new Scanner(System.in);
	
	//***********Main Method***********************//
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ContactClient client = new ContactClient();
		client.displayMenu();
	}
	
			//*******Display menu*********//
	public void displayMenu(){
		int choice;
		boolean validate=false;
		ContactsValidator service = new ContactsValidator(); 
		ContactDetails details = new ContactDetails();
		ContactsHelper helper = new ContactsHelper();
	
	    //******Enter your choice menu generation**********//
		while(true){
		System.out.println("Please enter your choice :");
		System.out.println("1. Add New Contact");
		System.out.println("2. Delete Contact");
		System.out.println("3. Exit");
		
		try {
			choice=Integer.parseInt(scan.nextLine());
		
		//*******Switch case to handle the choice selection*******//
		switch(choice){
		
		case 1:
			
			
			do{
				System.out.println("Enter Details:");
				details= takeUserInput();
				validate=service.validateDetails(details);
				if(!validate){
					System.out.println("Please Enter the correct Details");
				}
			}
			while(validate==false);
			helper.addContactDetails(details);
			
			break;
			
		case 2:
			
			
			System.out.println("Enter the contact ID: ");
			int contactID = Integer.parseInt(scan.nextLine());
			helper.deleteContactDetails(contactID);
			break;
			
		case 3:
			
			
			System.exit(0);
			
		default: 
			
			System.out.println("You have entered wrong choice");
		
		}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			System.out.println("Please enter valid choice");
		}
		}
	}
	
				
	
				//***Taking input from user****//
	
	
	public static ContactDetails takeUserInput(){
		ContactDetails details = new ContactDetails();
	
		System.out.print("Enter Name : ");
		details.setcName(scan.nextLine());
		
		System.out.print("Enter Mobile No. : ");
		details.setMobileNo1(scan.nextLine());
		
		System.out.print("Do you want to add alternate Mobile No. ? ");
		char ch;
		ch = scan.nextLine().charAt(0);
		if(ch=='Y' || ch=='y')
		{
			System.out.print("Enter Mobile No. : ");
			details.setMobileNo2(scan.nextLine());
		}
		else{
			details.setMobileNo2(null);
		}
		
		System.out.print("Enter Email Id : ");
		details.setEmailID(scan.nextLine());
		
		System.out.print("Select the Group (Friends/Family/CoWorkers) : ");
		String group=scan.nextLine().toUpperCase();
		details.setGroupName(group);
		
		return details;   //**Return back the details**//
	}
}
